# BOM fixture policy

The user authorizes choosing or adjusting fixture coordinates, blast positions and radii, cells to discard, bonds to break, seeds and tick counts when a specified fixture does not exercise the intended check. Record the chosen details and reason in the report, then continue without stopping.

Stop and ask only when a system rule (data model, failure rules, strengths, recipes, physics, snapshot format or byte-identity requirements) conflicts with the code or cannot be implemented as written. Fixture adjustments do not authorize changing these system rules.
