#+feature dynamic-literals
package shared



PRESET_LAYOUTS :: [5]string{
	#load("../presets/materials.json"),
	#load("../presets/tower.json"),
	#load("../presets/glass-house.json"),
	#load("../presets/rubber-pad.json"),
 #load("../presets/bridge.json"),
}
