#+feature dynamic-literals
package shared



NET_APP_COMMAND_RESULT :: u8(0xC8)

NET_APP_SETTINGS :: u8(0xC9)
