package main

import "core:math"
import "core:strings"

// Headless ownership of the authoritative world and its authored layout.
// Reuse construction with the existing table when the soak replenishes its yard.
