package main

import shared "shared"
import "core:time"

// Ephemeral damage transaction. Its lineage survives spatial refinement and
// provisional regrouping; no shock values or hit sources persist in the World.

