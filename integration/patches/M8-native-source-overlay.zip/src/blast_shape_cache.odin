package main
// Validation repeatedly asks the same pure questions while generating, staging
// and installing one polygon. Cache exact ordered f32 inputs for this blast only.
