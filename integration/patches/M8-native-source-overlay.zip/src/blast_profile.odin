package main

import shared "shared"
// Profiler implementation now lives in shared/shared.blast_profile.odin.
