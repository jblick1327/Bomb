package main

// Shared gameplay settings; no frontend dependencies.

