package main
// Conservative: shared_segments accepts endpoints within 1e-4 of a line.
// This padded box rejection cannot remove an accepted boundary overlap.
