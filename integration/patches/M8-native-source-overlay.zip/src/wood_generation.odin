package main

import "core:math"




// General straight half-plane clip. The same intersection arithmetic is used
// for both halves, so a slanted cut has exactly shared boundary vertices.



// Returns false for cross-grain seams, which retain the existing midpoint tent.

