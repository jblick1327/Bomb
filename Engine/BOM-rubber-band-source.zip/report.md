# Rubber band film

Render-only change, verified on Windows with Odin, Box2D 3.1.1 and raylib 5.5. Skin weights now follow live bonds within the blend radius. Presentation caches one hull band per rubber piece and render revision. Contact film retains its old segments and round joins; each gap gets one straight span. Fills, F3 region strokes and the V raw-body drawing path are unchanged. No simulation, material, physics or snapshot code changed. No commit was made.

| Check | Before | After |
| --- | ---: | ---: |
| A: specified bite, cross-gap weight references (7 outline points checked) | 0 | 0 |
| A: narrower-gap regression, forbidden top-point weight references | 1 | 0 |
| B2: bite/hole film segments off the rest hull | 33 | 0 |
| B2: single straight span across the bite top | 0 | 1 |
| B1: undamaged bend, width 0 / 2, changed pixels | reference | 0 / 0 |
| B1: Materials, width 0 / 2, changed pixels | reference | 0 / 0 |
| B3: MSAA interior / floor / glass / rubber-film defects | 0 / 0 / 0 / 0 | 0 / 0 / 0 / 0 |
| B3: bend shared-point mismatches; hub invalid/flipped triangles | 0; 0/0 | 0; 0/0 |

The requested A fixture already passes on the original build: its 0.8-wide bite exceeds `SKIN_RADIUS = 0.5`. It cannot demonstrate cross-gap weights. The fixture remains exactly as requested. A supplementary one-cell-wide bite (0.4 wide) exposes the bug at its top-left point: **1 → 0** forbidden references. The original-build failures were recorded before applying the fixes; the refined supplemental check also ran against a separate copy of the original source. Near the narrower bite's bottom, paths through the row below remain valid and are intentionally retained.

The bite uses the editor's 6×4 grid and discards the two top cells plus the interior cell as one failure set before physics starts. Its known outer rectangle independently checks the film: no film remains on the hole or inner bite edges. Width-0 before/after captures differ at 6,958 pixels. Every undamaged comparison covers all 1,600,000 framebuffer pixels, with no tolerance, using the actual **4× MSAA** window (1600×1000 physical pixels; 1280×800 logical).

**118 tests pass**, with allocation tracking enabled and no leak reports. Band tests cover revision reuse/invalidation, two independent bands after a split, pruning and cleanup after Scene destruction (0 tracked Odin bytes). Capture teardown reports 0 Odin bytes and 0 additional Box2D bytes. Native input and editor smokes pass. Rubber bend remains at 22 shared points, 0 mismatches and maximum turn 2.632007°; both 10°/30° hub checks pass unchanged. MSAA additionally checks 80 rubber-film midpoints, 195,200 floor pixels and 407,682 glass pixels; the glass crack guard is 58.

The blast-only and 600-tick v3 fixtures match the baseline **after Part A and after Part B**, byte-for-byte. Two same-process 600-tick replays also agree. Drawing leaves all capture snapshots unchanged; headless build/tick/explode/load cache ensures remain 0.

| Fixture | Bytes | SHA-256 |
| --- | ---: | --- |
| Blast-only | 249,537 | `d9c6641d63f87789a082f0d2dd0aa75932a7c1203f64a4c10eff7463523f16a3` |
| 600 ticks | 308,081 | `7f390656c76fd46ec5da65ad9a07c89bfa8eb1c1d6d0ec4f790d60db9b0ae548` |

Requested PNGs (width 0):

| Scene | Before | After |
| --- | --- | --- |
| Rubber bite | [PNG](evidence/rubber-band/before/rubber-bite-0.png) | [PNG](evidence/rubber-band/after/rubber-bite-0.png) |
| Materials, radius 6 at (-0.6,1), 30 ticks later | [PNG](evidence/rubber-band/before/materials-blast-0.png) | [PNG](evidence/rubber-band/after/materials-blast-0.png) |

The requested Materials blast pair is pixel-identical: its surviving rubber has a convex rest boundary, so all its old film segments are already hull contacts. No scenario parameters were adjusted to force a visual difference.

Logs, comparison counts and fixture hashes are in [evidence/rubber-band/](evidence/rubber-band/verification.json). Reproduce with `odin test src`, `--soak-fixture [prefix]`, `--smoke-msaa`, and `--capture-rubber-band [directory]` on the built executable. `odin check src` and `git diff --check` also pass.
