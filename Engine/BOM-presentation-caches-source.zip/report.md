# BOM — presentation caches and notice expiry

Render caches now belong to `Sandbox.render_caches`, outside World. `Render_Caches` is a cell-ID map; its presentation state owns the static signature/revision and last observed structure revision. The draw/measure pre-pass prunes dead keys after structure changes, then ensures all live entries before any cache pointers are read. Static signature math and cache validity/build logic are preserved. World records, structural commit, tick, physics, load and explosion code no longer reference cache contents or construct caches. Reset/load clear presentation caches when replacing a scene with potentially reused IDs.

1. **Headless cache work: 164,450 → 0 ensure calls** for `soak_yard`, 600 ticks and three fixture blasts. Breakdown: build **409 → 0**, tick **163,294 → 0**, explosion wrappers **747 → 0**. Snapshot load separately makes **300 → 0** calls. The counter is thread-local and compiled only under `ODIN_TEST`. The before run failed; the after run passes.

2. **Notice expiry: 3/3 failing → 0/3 failing.** After a notice and 3 seconds of `sandbox_advance`, Edit, Edit-with-panel and paused Test each retained **2.5 s** before; each has **0 s** after. The timer now decreases before the Edit/paused early return.

3. **Cache ownership/pruning passes.** At initial draw and after three blasts, live/cached counts are **256/256, 240/240, 225/225, 282/282**, with **0 stale keys** at every stage. World snapshot bytes remain unchanged by each pre-pass. Repeating a pre-pass without a structure change makes **0 additional static-signature scans**. After Scene destruction, pruning empties the map; presentation cleanup leaves **0 tracked Odin bytes / 0 additional Box2D bytes**.

4. **Simulation and graphics verification pass.** Both blast-only and 600-tick v3 fixtures are byte-identical to the current-build baselines, with **0 mismatching bytes**; each fixture command also verifies two same-process replays. Final suite: **114 tests pass, no leaks reported**. Rubber bend and hub tests pass. Native input and editor smokes pass; drawing builds 153 presentation caches while leaving World snapshot bytes unchanged. Editor smoke cleanup leaves **0 Odin bytes / 0 additional Box2D bytes**. Actual 4× MSAA checks remain **0**: interior defects, floor bright pixels (195,200 sampled), glass bright pixels (407,682 sampled; 58 live crack boundaries), and rubber-film defects (80 sampled). `odin check src` and `git diff --check` pass.

5. **Before/after timing observations**, optimized `-o:speed`, seed 42, same workloads; milliseconds:

| Workload / measurement | Before | After |
| --- | ---: | ---: |
| Existing 1-minute falling-bombs soak: tick mean, 3,600 ticks | 0.970754 | 1.076379 |
| Same soak: worst blast pass, 33 blasts | 10.047600 | 12.354700 |
| Five 600-tick fixture replays: tick mean, 3,000 ticks | 0.714245 | 0.846840 |
| Same replays: worst complete explosion wrapper, 15 blasts | 8.913900 | 6.817000 |

The existing soak's blast event timer measures `blast_pass`; the separate fixture timer includes the complete explosion wrapper, including the old cache preparation. Tick measurements include the existing Sandbox tick wrapper. No performance budget or tuning changes were applied.

Evidence and hashes: `evidence/presentation-caches/`. Reproduce with:

```powershell
odin test src -o:speed -out:build/BOM-tests.exe
scripts/bom.ps1 Build
build/BOM.exe --soak-fixture output/check
build/BOM.exe --smoke-msaa
build/BOM.exe --smoke-input
build/BOM.exe --smoke-editor
build/BOM.exe --soak 1
build/BOM.exe --bench-presentation
```

Source: [BOM-presentation-caches-source.zip](BOM-presentation-caches-source.zip). No PNGs included. No commit made.
