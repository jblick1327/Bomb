# Glass shock

Implemented the specified bond transport with Glass `shock_loss = 4`, zero for other palette materials and floor. Blast sources use pre-blast piece geometry; impact sources retain the strongest Box2D hit's point/load. Sorted Dijkstra propagation runs after direct damage, followed by one shock generation with no sibling glue, inherited loads, and qualifying bond breaks. Both paths retain **one structural commit** and add no shock impulse. No strengths, recipes, welds or physics-step tuning changed. No commit was made.

**1–2. Before/after measurements:** the pane uses the editor path, seed 42, 5×2.5 bounds (0,0)–(5,2.5), 120 settle ticks, blast at (-0.6,1.25), measured immediately afterward. The drop is Glass 2×1, lifted 0.8 above the floor and stopped immediately after its first damaging batch, tick 25 in both builds.

| Scenario | Pieces before → after | Largest piece / surviving area before → after |
| --- | ---: | ---: |
| Pane, radius 3 | 26 → 58 | 0.91167849 → **0.72288132** |
| Pane, radius 4 | 18 → 192 | 0.92429191 → **0.02727782** |
| Flat drop | 8 → 56 | 0.88401365 → **0.11295225** |

All three regression cases failed on the original build before implementation. **The radius-3 prototype range of 0.4–0.6 is not achieved.** Its regression verifies improvement against the recorded baseline; it does not assert that prediction. Radius 4 meets the predicted ≤0.05. The prescribed loss and centroid-path costs remain unchanged; the independent chain test gives loads 22/18/14/10/6 and proves shock cannot jump a missing bond.

Median physical shard area (m²), binned by area-weighted piece-centroid distance from the blast. Each disconnected piece counts once, including the largest. “—” means no surviving piece centroid in that band.

| Pane | 0–2 m | 2–4 m | 4+ m |
| --- | ---: | ---: | ---: |
| Radius 3, before | 0.03091689 | 10.1211929 | — |
| Radius 3, after | 0.02641096 | 0.03988999 | 7.1794896 |
| Radius 4, before | — | 0.03052580 | 7.6362839 |
| Radius 4, after | — | 0.02608180 | 0.02804148 |

The remaining radius-3 bulk is one far piece. Logical-cell medians and band counts are also recorded in [verification.json](evidence/glass-shock/verification.json).

**3. Non-glass identity:** the control includes Wood, Stone, Rubber and floor, three fixture blasts, and no Glass material entry (including unused palette entries). It remains byte-identical: **258,683 bytes**, SHA-256 `60cff3d46c107ce97e005fa013e0c5f805de2012a5d13693709a13932cb3f485`. Disabled `shock_loss` is omitted; older snapshots default to zero. Enabled values round-trip exactly, including signed-zero handling in the wire tests. Glass-containing v3 fixtures are re-baselined: blast-only **249,436 bytes**, 600-tick **303,886 bytes**. Two same-process 600-tick replays agree exactly; full hashes accompany the report.

**4. Preset settling:** every preset retains its own initial counts throughout all 600 idle ticks, with no coordinate changes. Glass house does not shatter.

| Preset | Regions tick 0 → 600 | Links tick 0 → 600 | Maximum whole-piece rotation |
| --- | ---: | ---: | ---: |
| Materials | 233 → 233 | 510 → 510 | 1.820673° |
| Tower | 184 → 184 | 417 → 417 | 0.023043° |
| Glass house | 183 → 183 | 423 → 423 | 0.151994° |
| Rubber pad | 185 → 185 | 425 → 425 | 0.706466° |

**5. Verification and timing:** **129 tests pass**, including the unchanged 32-seed geometry, Wood, rubber bend/hub, snapshot and leak checks. A final targeted run also passes the stricter one-generation child count. No leaks are reported. Test-only counters measure blast/impact commits **1/1 → 1/1**. MSAA interior/floor/glass/rubber-film defects stay **0 → 0**; the glass crack guard counts 337 real boundaries. Native input and editor smokes pass; editor teardown is 0 Odin bytes / 0 additional Box2D bytes.

Three serial 20-minute seed-42 falling-bombs soaks per build, `-o:speed`, ordinary two-minute refills and allocation tracking. Worst blast times per run: before **17.1042 / 14.4029 / 13.7024 ms**; after **41.4343 / 22.0312 / 22.1798 ms**. Median worst `blast_pass`: **14.4029 → 22.1798 ms**. No physics tests or graphics smokes overlapped those runs. All six finish with **0 Odin bytes and 0 Box2D bytes**, with stored/live counts equal at every minute.

Requested width-2 PNGs, actual 4× MSAA, identical before/after cameras:

| Scene | Before | After |
| --- | --- | --- |
| Radius-3 pane, 30 ticks after blast | [PNG](evidence/glass-shock/before/pane-r3-2.png) | [PNG](evidence/glass-shock/after/pane-r3-2.png) |
| Radius-4 pane, 30 ticks after blast | [PNG](evidence/glass-shock/before/pane-r4-2.png) | [PNG](evidence/glass-shock/after/pane-r4-2.png) |
| Glass house, radius 4 at (-2,1), 60 ticks later | [PNG](evidence/glass-shock/before/glass-house-2.png) | [PNG](evidence/glass-shock/after/glass-house-2.png) |

The Glass house pair is pixel-identical for this hit; no scenario parameters were changed to force a difference. Drawing leaves each saved World unchanged. Reproduce with `odin test src` and executable flags `--glass-study [directory]`, `--capture-glass [directory]`, `--soak-fixture [prefix]`, `--smoke-msaa`, and `--soak 20`. `odin check src` and `git diff --check` pass.
