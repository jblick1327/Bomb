# BOM blast cover performance

**Timing passes. Part 1 passes. Part 2 remains incompletely equivalent:** the 23 fixed fixtures match, but the extended 20-minute trajectory diverges.

Part 1: **23/23 fixtures byte-identical**, with identical same-process replays. Original-piece shadow flags use convex-hull/polygon overlap after bounds rejection; descendants inherit flags. Remaining rays traverse a one-metre snapshot grid, skip their original owner, and sum in cell-ID order. Ray scratch is reused. Exact memoization, failure-load upper bounds, zero-load termination, cached boundaries, failed-partition reuse, stack hulls and generation scratch reduce repeated work. Completed outlines retain owned storage; cache collisions verify full float inputs.

Part 2: **23/23 fixed fixtures match** in the multiset of surviving rest outlines, full pose float bits (including signed zero), and piece partition, ignoring IDs. Seventeen snapshots remain byte-identical; six change IDs. [Per-fixture comparison](evidence/cover-performance/fixture-comparison.md) includes every re-baseline.

Literal restoration of the extent-only reach heuristic mismatched five fixtures: blast-only, ticked, non-Glass control, non-Wood control, and radius-3 Glass, with 12, 3, 3, 15 and 3 differing outlines. Disabling new reach pruning removed these mismatches; disabling deletion did not. Extent alone omits the blast-to-cell offset and cannot prove whole-cell erasure. The candidate retains it only in legacy cases and requires the existing farthest-point proof for new cases. Rejected snapshots are retained.

**Extended 20-minute check: Part 2 FAIL.** Part 1 remains byte-identical, with counts [87, 18, 75]. Part 2 changes counts to [102, 19, 88] (cells/links/pieces), with different outlines, poses and partition. The controlled toggle isolates this to shortcut activation and its different intermediate staging/body history; the first divergent solver step is not localized. The default build is this Part 2 candidate; use `-define:COVER_SHORTCUTS=false` for identical Part 1 behavior. [Extended comparison](evidence/cover-performance/extended-comparison.json) and complete snapshots are included.

Timing **PASS**: three sequential 20-minute soaks, with no concurrent test/compiler jobs, have worst blast passes 29.4366, 23.0462, 25.6077 ms. Median **25.6077 ms** versus the **26 ms** limit (-73.0% versus the previous cover median; +22.5% versus 20.9 ms).

The separate profiled 20-minute soak's worst blast is **22.7875 ms**, tick **43553**. No-cover flags handled **63,730/1,097,159 samples (5.809%)** overall and **1970/4177 (47.163%)** at that event. There were 146,914 memoized query hits and 606,557 geometric failure-upper-bound skips; these counters are not disjoint from flag counts.

The competing game and download process had exited, and all compiler/test runs had finished before these measurements. Earlier contended probes are excluded; the 94.9/20.9 ms figures are historical references.

| Phase | ms at worst profiled blast |
|---|---:|
| Refinement | 12.3732 |
| Direct recursion | 3.0171 |
| Glass source / travel | 0.0008 |
| Glass staging | 0.0000 |
| Glass bond breaking | 0.0000 |
| Regrouping (nested) | 2.0052 |
| Commit | 1.3632 |
| Physics synchronization | 3.8447 |
| Impulse loop / motion read | 0.5067 |
| Generation (nested) | 3.9408 |
| Inheritance (nested) | 2.6226 |
| Sibling attachment (nested) | 0.5400 |
| Containment scans (nested) | 0.0000 |
| Shared boundaries (nested) | 0.5198 |
| Inheritance queries (nested) | 0.0664 |
| Cover ray queries (nested) | 0.6960 |
| Shadow checks (nested) | 0.9655 |
| Cover snapshot / index build | 0.8774 |

Nested timings overlap their containing phases and must not be summed.

Wall fixture unchanged: Stone (2,0)-(2.4,2.4), Wood (2.6,0)-(3.6,1.6), seed 42, blast (1,1), radius 5. Wood lost area **0.000000358 m^2** (rounding), **0 failed cells**. The 16-seed Wood mean crater remains **6.88093281 m^2**. Bridge settles 600 ticks without breaks: 272 cells, 592 links, 5 pieces, 6 mortar. C2 removes 2 mortar, then 4 force breaks leave 0. Deck crosses y=1 at tick **98**, minimum y **0.221174106**, matching baseline. No fixture adjustments.

**146 tests pass**, with allocation tracking and no leak reports. Differential checks cover indexed rays, hull storage, scratch generation, cache collisions and zero-load termination. MSAA defects remain **0**. All three measured soaks and the profiled soak release all tracked Odin and Box2D bytes after teardown.

Reproduce: `odin build src -o:speed -out:build/BOM.exe`, then three sequential `--soak 20` runs. Profile with `-define:BOM_PROFILE=true`. `-define:COVER_SHORTCUTS=false` selects Part 1. `scripts/compare-cover.py` and `scripts/analyze-cover-extended.py` reproduce both comparisons; raw snapshots and logs are included. Extracted-source `odin check` and archive CRC verification pass.
