package main
import rl "vendor:raylib"

MATERIAL_SWATCHES :: [12][3]u8{
 {180,136,82},{86,153,174},{162,112,184},{131,145,152},
 {231,104,91},{244,177,79},{236,215,119},{111,220,190},
 {102,160,231},{218,137,190},{225,230,222},{66,77,104},
}
materials_sync_name :: proc(game:^Sandbox) {
 game.material_name_buffer={}; game.material_name_edit=false
 if game.material_selected>=4 {
  name:=game.layout.materials[game.material_selected-4].name
  copy(game.material_name_buffer[:80],transmute([]u8)name)
 }
}
materials_commit_name :: proc(game:^Sandbox) {
 if game.material_selected<4 { return }
 name:=string(cstring(raw_data(game.material_name_buffer[:])))
 if name!=game.layout.materials[game.material_selected-4].name { materials_rename(game,game.material_selected-4,name) }
 materials_sync_name(game)
}
sandbox_set_materials_panel :: proc(game:^Sandbox) {
 sandbox_set_panel(game,true); game.materials_open=true
 game.material_selected=clamp(game.material_selected,0,palette_count(&game.layout)-1)
 materials_sync_name(game)
}
sandbox_draw_materials_panel :: proc(game:^Sandbox,width,height:f32)->Sandbox_UI_Action {
 rl.DrawRectangle(0,0,i32(width),i32(height),{8,14,23,205})
 x,y:=(width-820)*0.5,(height-560)*0.5
 rl.DrawRectangleRounded({x,y,820,560},0.025,8,{23,35,49,255})
 rl.DrawText("MATERIALS / PAUSED",i32(x+24),i32(y+22),24,YARD_INK)
 if rl.GuiButton({x+696,y+20,100,32},"Close") { materials_commit_name(game); return .Resume }
 rl.GuiSetStyle(.DEFAULT,i32(rl.GuiDefaultProperty.TEXT_SIZE),16)
 defer rl.GuiSetStyle(.DEFAULT,i32(rl.GuiDefaultProperty.TEXT_SIZE),18)
 for i in 0..<palette_count(&game.layout) {
  m:=layout_material(&game.layout,Palette(i)); row:=y+76+f32(i)*48
  active:=game.material_selected==i
  _ = rl.GuiToggle({x+24,row,174,36},rl.TextFormat("%s",m.name),&active)
  if active && game.material_selected!=i {
   materials_commit_name(game); game.material_selected=i; materials_sync_name(game)
  }
  rl.DrawRectangle(i32(x+202),i32(row+7),7,22,material_color(m))
  if i<4 {
   if len(game.layout.materials)>=4 { rl.GuiDisable() }
   if rl.GuiButton({x+220,row,90,36},"Duplicate") { materials_commit_name(game); materials_duplicate(game,Palette(i)) }
   rl.GuiEnable()
  }
 }
 px,py:=x+346,y+80
 selected:=game.material_selected
 if selected<4 {
  rl.DrawText(rl.TextFormat("%s / built-in",editor_material(Palette(selected)).name),i32(px),i32(py),24,YARD_ACCENT)
  rl.DrawText("Fixed recipe. Duplicate to customise.",i32(px),i32(py+46),18,YARD_MUTED)
 } else {
  index:=selected-4; m:=&game.layout.materials[index]
  rl.DrawText("NAME",i32(px),i32(py),16,YARD_MUTED)
  if rl.GuiTextBox({px,py+24,426,34},cstring(raw_data(game.material_name_buffer[:])),81,game.material_name_edit) {
   if game.material_name_edit { materials_commit_name(game) } else { game.material_name_edit=true }
  }
  name:=string(cstring(raw_data(game.material_name_buffer[:])))
  if game.material_name_edit && name!=m.name && material_name_problem(&game.layout,name,index)=="" { materials_rename(game,index,name) }
  rl.DrawText(rl.TextFormat("BASE  %s  /  fixed recipe family",editor_material(m.base).name),i32(px),i32(py+72),17,YARD_MUTED)
  old:=m^
  sandbox_slider(px,py+110,426,"Toughness",&m.toughness,0.25,4,true)
  sandbox_slider(px,py+171,426,"Blast resistance",&m.blast_resistance,0,6,true)
  switch m.base {
  case .Wood:sandbox_slider(px,py+232,426,"Strip thickness",&m.strip_thickness,0.12,0.6,true)
  case .Glass:sandbox_slider(px,py+232,426,"Shock loss",&m.shock_loss,1,12,true)
  case .Rubber:sandbox_slider(px,py+232,426,"Flexibility  /  lower = stiffer",&m.flexibility,0.2,1,true)
  case .Stone:
  }
  rl.DrawText("COLOUR",i32(px),i32(py+299),16,YARD_MUTED)
  for c,i in MATERIAL_SWATCHES {
   box:=rl.Rectangle{px+f32(i)*35,py+326,29,29}
   rl.DrawRectangleRec(box,{c[0],c[1],c[2],255})
   if m.color==c { rl.DrawRectangleLinesEx({box.x-2,box.y-2,33,33},2,YARD_INK) }
   if rl.IsMouseButtonReleased(.LEFT) && rl.CheckCollisionPointRec(rl.GetMousePosition(),box) { m.color=c }
  }
  if old.toughness!=m.toughness || old.blast_resistance!=m.blast_resistance || old.strip_thickness!=m.strip_thickness || old.shock_loss!=m.shock_loss || old.flexibility!=m.flexibility || old.color!=m.color { sandbox_layout_changed(game) }
  if rl.GuiButton({px,py+390,130,34},"Delete") { materials_delete(game,index) }
  rl.DrawText("Delete requires no placed objects.",i32(px+144),i32(py+399),15,YARD_MUTED)
 }
 if game.status_time>0 { rl.DrawText(rl.TextFormat("%s",game.status),i32(x+346),i32(y+508),17,YARD_ACCENT) }
 rl.DrawText("Tab / Escape closes  /  Changes autosave",i32(x+24),i32(y+528),16,YARD_MUTED)
 return .None
}
material_palette_label :: proc(index:int,name:string,width:f32)->cstring {
 remaining:=name
 label:=rl.TextFormat("%d %s",index+1,remaining)
 for len(remaining)>0 && f32(rl.MeasureText(label,13))>width-8 {
  end:=len(remaining)-1
  for end>0 && remaining[end]&0xc0==0x80 { end-=1 }
  remaining=remaining[:end]; label=rl.TextFormat("%d %s.",index+1,remaining)
 }
 return label
}
