package main

import "core:math"
import b2 "vendor:box2d"
import rl "vendor:raylib"

Built_Object :: struct { identity: u64, mortar: bool, lo,hi: Vec2, first_id,end_id: u64 }
MORTAR_STRENGTH :: f32(280)
MORTAR_COLOR :: rl.Color{236,226,198,255}
mortar_length :: proc(c: Connection) -> f32 {
 result:f32; for segment in c.rest_segments { result+=vlen(vsub(segment.b,segment.a)) }; return result
}
mortar_local_anchor :: proc(s: ^Scene,sub: Subdivision,rest_point: Vec2) -> Vec2 {
 if s.materials[sub.material].flexibility==0 { return rest_point }
 return vsub(rest_point,sub.rest_center)
}
object_cells :: proc(s: ^Scene,obj: Built_Object) -> [dynamic]u64 {
 result:[dynamic]u64
 for sub in s.subdivisions { if sub.live && obj.first_id<=sub.id && sub.id<obj.end_id { append(&result,sub.id) } }
 sort_ids(result[:]); return result
}
mortar_touch :: proc(a,b: Built_Object) -> bool {
 return ((a.hi.x==b.lo.x || b.hi.x==a.lo.x) && min(a.hi.y,b.hi.y)-max(a.lo.y,b.lo.y)>0) ||
        ((a.hi.y==b.lo.y || b.hi.y==a.lo.y) && min(a.hi.x,b.hi.x)-max(a.lo.x,b.lo.x)>0)
}
mortar_bounds :: proc(p: Polygon) -> (lo,hi: Vec2) {
 lo={1e30,1e30}; hi={-1e30,-1e30}
 for v in p.points { lo={min(lo.x,v.x),min(lo.y,v.y)}; hi={max(hi.x,v.x),max(hi.y,v.y)} }; return
}
mortar_cells :: proc(s: ^Scene,cells_a,cells_b: []u64) {
 for a in cells_a { for b in cells_b {
  sa,sb:=s.subdivisions[s.sub_rows[a]],s.subdivisions[s.sub_rows[b]]
  alo,ahi:=mortar_bounds(sa.outline); blo,bhi:=mortar_bounds(sb.outline)
  if ahi.x<blo.x || bhi.x<alo.x || ahi.y<blo.y || bhi.y<alo.y { continue }
  if length,_:=shared_boundary(sa.outline,sb.outline); length>0 { add_connection(s,a,b,true) }
 } }
}
build_mortar :: proc(s: ^Scene,objects: []Built_Object,ground: Built_Object) {
 for i in 0..<len(objects) { for j in i+1..<len(objects) {
  a,b:=objects[i],objects[j]
  if (a.mortar || b.mortar) && mortar_touch(a,b) {
   left,right:=object_cells(s,a),object_cells(s,b)
   mortar_cells(s,left[:],right[:]); delete(left); delete(right)
  }
 } }
 for a in objects { if a.mortar && a.lo.y==0 {
  left,right:=object_cells(s,a),object_cells(s,ground)
  mortar_cells(s,left[:],right[:]); delete(left); delete(right)
 } }
}
draw_mortar :: proc(s: ^Scene,view: View,poses,frames: map[u64]Pose,outline_width: f32) {
 ids:[dynamic]u64; defer delete(ids)
 for c in s.connections { if c.live && c.mortar { append(&ids,c.id) } }; sort_ids(ids[:])
 for id in ids {
  c:=s.connections[s.conn_rows[id]]; sub:=s.subdivisions[s.sub_rows[c.a]]
  rigid:=s.materials[sub.material].flexibility==0
  frame:=rigid_render_frame(s,sub,poses,frames)
  posed:=render_subdivision(s,sub,poses,frames)
  for segment in c.rest_segments {
   a,b:=posed_point(posed,segment.a),posed_point(posed,segment.b)
   if rigid { a=rigid_render_point(frame,segment.a); b=rigid_render_point(frame,segment.b) }
   rl.DrawLineEx(screen_point(view,a),screen_point(view,b),max(f32(2),outline_width),MORTAR_COLOR)
  }
 }
}

// Groups are emitted by their smallest connection ID; members are sorted by ID.
// The first member fixes the force orientation for the unordered body pair.
Mortar_Seam :: struct {
 bodies: [2]b2.BodyId,
 members: [dynamic]u64,
 length: f32,
 center, force: Vec2,
 torque: f32,
 overload_ticks: u8,
}
mortar_seams :: proc(s: ^Scene) -> [dynamic]Mortar_Seam {
 seams:[dynamic]Mortar_Seam
 rows:=make(map[[2]b2.BodyId]int); defer delete(rows)
 ids:[dynamic]u64; defer delete(ids)
 for c in s.connections { if c.live && c.mortar && c.joint!=b2.nullJointId && b2.Joint_IsValid(c.joint) { append(&ids,c.id) } }
 sort_ids(ids[:])
 for id in ids {
  c:=s.connections[s.conn_rows[id]]
  bodies:=[2]b2.BodyId{b2.Joint_GetBodyA(c.joint),b2.Joint_GetBodyB(c.joint)}
  row,ok:=rows[bodies]
  if !ok { row,ok=rows[[2]b2.BodyId{bodies[1],bodies[0]}] }
  if !ok { row=len(seams); rows[bodies]=row; append(&seams,Mortar_Seam{bodies=bodies}) }
  seam:=&seams[row]; length:=mortar_length(c)
  append(&seam.members,id)
  seam.length+=length
  seam.center=vadd(seam.center,vmul(connection_sample(s,c),length))
  // New members / merged groups can have different histories: retain the
  // largest surviving history, then write the group value to every member.
  seam.overload_ticks=max(seam.overload_ticks,c.overload_ticks)
 }
 for &seam in seams {
  seam.center=vmul(seam.center,1/seam.length)
  for id in seam.members {
   c:=s.connections[s.conn_rows[id]]
   force:=from_b2(b2.Joint_GetConstraintForce(c.joint))
   torque:=b2.Joint_GetConstraintTorque(c.joint)
   body:=seam.bodies[1]
   local:=b2.Joint_GetLocalAnchorB(c.joint)
   if b2.Joint_GetBodyB(c.joint)!=body {
    force=vmul(force,-1); torque=-torque; local=b2.Joint_GetLocalAnchorA(c.joint)
   }
   point:=from_b2(b2.Body_GetWorldPoint(body,local))
   seam.force=vadd(seam.force,force)
   seam.torque+=torque+vcross(vsub(point,seam.center),force)
  }
 }
 return seams
}
mortar_free_seams :: proc(seams: [dynamic]Mortar_Seam) {
 for seam in seams { delete(seam.members) }; delete(seams)
}
mortar_seam_need :: proc(seam: Mortar_Seam) -> f32 {
 return vlen(seam.force)/seam.length+2*math.abs(seam.torque)/(seam.length*seam.length)
}
mortar_force_failures :: proc(s: ^Scene,failures: ^Failures) {
 seams:=mortar_seams(s); defer mortar_free_seams(seams)
 for seam in seams {
  mortar_apply_seam(s,seam,failures)
 }
}

mortar_apply_seam :: proc(s: ^Scene,seam: Mortar_Seam,failures: ^Failures) {
  r:=vlen(seam.force)/(MORTAR_STRENGTH*seam.length)+math.abs(seam.torque)/(0.5*MORTAR_STRENGTH*seam.length*seam.length)
  broken:=r>=2 || r>=1 && u16(seam.overload_ticks)+1>=3
  counter:=u8(0); if !broken && r>=1 { counter=seam.overload_ticks+1 }
  for id in seam.members {
   s.connections[s.conn_rows[id]].overload_ticks=counter
   if broken {
    append(&failures.connections,id)
    when BOM_MORTAR_MEASURE { mortar_measured_force_breaks+=1 }
   }
  }
}
