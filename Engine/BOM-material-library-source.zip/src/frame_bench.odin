package main
import rl "vendor:raylib"
import "core:time"
import "core:fmt"
BOM_FRAME_BENCH :: #config(BOM_FRAME_BENCH,false)
when BOM_FRAME_BENCH {
 frame_measuring: bool
 frame_cache_ms,frame_physics_ms: f64
 foreign import frame_gl "system:opengl32.lib"
 foreign frame_gl { @(link_name="glFinish") frame_gl_finish :: proc "system" () --- }
 frame_ms :: proc(start:time.Tick)->f64 { return f64(time.tick_diff(start,time.tick_now()))/f64(time.Millisecond) }
 run_frame_bench :: proc() {
  rl.SetTraceLogLevel(.WARNING)
  rl.SetConfigFlags({.MSAA_4X_HINT,.WINDOW_HIGHDPI,.WINDOW_RESIZABLE})
  rl.InitWindow(1280,800,"BOM native full-frame timings"); defer rl.CloseWindow()
  sandbox_gui_style(); rl.SetShapesTexture(rl.Texture2D{},rl.Rectangle{}); rl.SetTargetFPS(0)
  samples,buffers:i32; msaa_gl_integer(0x80a9,&samples); msaa_gl_integer(0x80a8,&buffers)
  fmt.printf("Native: logical=%dx%d framebuffer=%dx%d samples=%d buffers=%d profile=%v; GPU completion included; FPS sleep disabled\n",rl.GetScreenWidth(),rl.GetScreenHeight(),rl.GetRenderWidth(),rl.GetRenderHeight(),samples,buffers,BOM_PROFILE)
  targets:=[8]int{14774,21777,28878,36252,43553,50727,57674,64843}
  fmt.println("run,tick,kind,full_frame_ms,tick_ms,blast_ms,physics_pipeline_ms,draw_submit_swap_ms,cache_ms,gpu_finish_ms,regions,links,pieces")
  for run in 1..=3 {
   g:=soak_yard(); sandbox_fixture_mode(&g,.Falling_Bombs)
   poses:=make(map[u64]Pose); blast:=Soak_Timing{}; g.blast_timing=&blast
   for tick in 1..=72000 {
    if tick>1 && (tick-1)%7200==0 { soak_rebuild_layout(&g) }
    draw,measure,hit:=false,false,false
    for target in targets {
     draw=draw || tick>=target-2 && tick<=target+1
     measure=measure || tick==target || tick==target+1
     hit=hit || tick==target
    }
    frame_measuring=measure; frame_cache_ms=0; frame_physics_ms=0; blast={}
    start:=time.tick_now(); sandbox_tick(&g,0,false); tick_ms:=frame_ms(start)
    if !draw { continue }
    draw_start:=time.tick_now()
    clear(&poses); g.accumulator=0
    for sub in g.world.scene.subdivisions {
     if !sub.live { continue }; pose:=sub.pose
     if old,ok:=g.previous[sub.id]; ok { pose=interpolate_region_pose(&g.world.scene,sub,old,0) }
     poses[sub.id]=pose
    }
    frames:=render_piece_frames(&g.world.scene,poses,g.previous,0)
    view:=sandbox_view(f32(rl.GetScreenWidth()),f32(rl.GetScreenHeight()))
    rl.BeginDrawing(); rl.ClearBackground({19,28,42,255})
    sandbox_draw_world(&g,view,poses,frames)
    _=sandbox_draw_hud(&g,f32(rl.GetScreenWidth()),f32(rl.GetScreenHeight()))
    rl.EndDrawing(); delete(frames)
    draw_ms:=frame_ms(draw_start); gpu_start:=time.tick_now(); frame_gl_finish(); gpu_ms:=frame_ms(gpu_start)
    total:=frame_ms(start); frame_measuring=false
    if measure {
     r,l,p:=counts_runtime(&g.world.scene); kind:=string("next"); if hit { kind="blast" }
     fmt.printf("%d,%d,%s,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%d,%d,%d\n",run,tick,kind,total,tick_ms,blast.total_ms,frame_physics_ms,draw_ms,frame_cache_ms,gpu_ms,r,l,p)
    }
   }
   path:=fmt.aprintf("evidence/frame-timing/final-%d.json",run); assert(save_world_snapshot(&g.world,path)); delete(path)
   delete(poses); sandbox_destroy(&g)
  }
 }
}
