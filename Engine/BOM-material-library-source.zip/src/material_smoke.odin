package main
import rl "vendor:raylib"
import b2 "vendor:box2d"
import win "core:sys/windows"
import "core:mem"
import "core:os"
import "core:fmt"
import "core:time"

run_material_smoke :: proc() {
 assert(os.make_directory_all("evidence/material-library")==nil)
 rl.SetTraceLogLevel(.WARNING); rl.SetConfigFlags({.MSAA_4X_HINT,.WINDOW_HIDDEN,.WINDOW_RESIZABLE,.WINDOW_HIGHDPI})
 rl.InitWindow(1280,800,"Material library native verification"); defer rl.CloseWindow()
 sandbox_gui_style(); rl.SetShapesTexture(rl.Texture2D{},rl.Rectangle{}); rl.SetTargetFPS(0); rl.SetExitKey(.KEY_NULL)
 track:mem.Tracking_Allocator; mem.tracking_allocator_init(&track,context.allocator); defer mem.tracking_allocator_destroy(&track)
 context.allocator=mem.tracking_allocator(&track)
 before:=b2.GetByteCount()
 defer { fmt.printf("Materials native teardown: Odin=%d Box2D delta=%d\n",track.current_memory_allocated,b2.GetByteCount()-before); assert(track.current_memory_allocated==0 && b2.GetByteCount()==before) }
 directory:=fmt.aprintf("output/material-smoke-%d",time.to_unix_nanoseconds(time.now())); defer delete(directory)
 assert(os.make_directory_all(directory)==nil)
 g:=sandbox_editor_create(); defer sandbox_destroy(&g); g.layout_directory=directory
 target:=rl.LoadRenderTexture(1280,800); defer rl.UnloadRenderTexture(target)
 sandbox_smoke_frame(&g,target,smoke_mouse(20,40),smoke_button(false))
 sandbox_smoke_click(&g,target,930,43); assert(g.materials_open && g.panel_open)
 sandbox_smoke_click(&g,target,495,214); assert(len(g.layout.materials)==1 && g.material_selected==4)
 sandbox_smoke_frame(&g,target,smoke_key(.EIGHT,true)); sandbox_smoke_frame(&g,target,smoke_key(.EIGHT,false))
 assert(g.editor.palette==.Wood && !g.editor.dragging)
 library:=win.LoadLibraryW("user32.dll"); defer win.FreeLibrary(library)
 post_message:=cast(proc "system" (hwnd:rawptr,msg:u32,wparam:uintptr,lparam:int)->i32)win.GetProcAddress(library,"PostMessageW")
 // Native WM_CHAR events exercise raygui's character queue, including Backspace.
 sandbox_smoke_click(&g,target,740,241); assert(g.material_name_edit)
 sandbox_smoke_frame(&g,target,smoke_key(.END,true)); sandbox_smoke_frame(&g,target,smoke_key(.END,false))
 for _ in 0..<6 { sandbox_smoke_frame(&g,target,smoke_key(.BACKSPACE,true)); sandbox_smoke_frame(&g,target,smoke_key(.BACKSPACE,false)) }
 for r in "Coral wood" {
  post_message(rl.GetWindowHandle(),0x0102,uintptr(r),1)
  sandbox_smoke_frame(&g,target); sandbox_smoke_frame(&g,target)
 }
 sandbox_smoke_frame(&g,target,smoke_key(.ENTER,true)); sandbox_smoke_frame(&g,target,smoke_key(.ENTER,false))
 assert(g.layout.materials[0].name=="Coral wood",g.layout.materials[0].name)
 // Click the live slider and a colour swatch.
 sandbox_smoke_click(&g,target,890,343)
 sandbox_smoke_click(&g,target,735,551)
 assert(g.layout.materials[0].toughness>2 && g.layout.materials[0].color==MATERIAL_SWATCHES[4])
 sandbox_smoke_frame(&g,target)
 sandbox_smoke_export(target,"evidence/material-library/materials-panel.png")
 for i in 1..<4 {
  sandbox_smoke_click(&g,target,495,214+i32(i)*48)
  sandbox_smoke_click(&g,target,590+i32(i+6)*35,540)
 }
 assert(len(g.layout.materials)==4)
 sandbox_smoke_frame(&g,target,smoke_key(.TAB,true)); sandbox_smoke_frame(&g,target,smoke_key(.TAB,false))
 assert(!g.panel_open && !g.materials_open)
 keys:=[4]rl.KeyboardKey{.FIVE,.SIX,.SEVEN,.EIGHT}
 for key,i in keys {
  sandbox_smoke_frame(&g,target,smoke_key(key,true)); sandbox_smoke_frame(&g,target,smoke_key(key,false))
  assert(int(g.editor.palette)==i+4)
  x:=f32(i)*2
  editor_smoke_drag(&g,target,{x,0},{x+1.4,1.5})
 }
 assert(len(g.layout.objects)==4)
 // Minimum-width capture: same live HUD and all eight toggle buttons.
 rl.SetWindowSize(900,700)
 narrow:=rl.LoadRenderTexture(900,700); defer rl.UnloadRenderTexture(narrow)
 sandbox_smoke_frame(&g,narrow); sandbox_smoke_export(narrow,"evidence/material-library/edit-eight-materials.png")
 rl.SetWindowSize(1280,800)
 sandbox_smoke_frame(&g,target)
 sandbox_smoke_click(&g,target,930,43)
 sandbox_smoke_click(&g,target,340,406) // Select custom Wood.
 sandbox_smoke_click(&g,target,640,595)
 assert(g.status=="In use by 1 objects" && len(g.layout.materials)==4)
 sandbox_smoke_frame(&g,target,smoke_key(.ESCAPE,true)); sandbox_smoke_frame(&g,target,smoke_key(.ESCAPE,false))
 sandbox_smoke_click(&g,target,810,43); assert(!g.editor.editing)
 sandbox_fixture_radius(&g,4)
 // Real queued Test click at a clear point next to the first object.
 p:=screen_point(sandbox_view(1280,800),{-0.2,0.7})
 sandbox_smoke_click(&g,target,i32(p.x),i32(p.y))
 for _ in 0..<12 { sandbox_smoke_frame(&g,target) }
 sandbox_smoke_export(target,"evidence/material-library/test-custom-blast.png")
 sandbox_smoke_click(&g,target,810,43); assert(g.editor.editing)
 // Save/load through the native Ctrl+S and Layouts widgets.
 sandbox_smoke_frame(&g,target,smoke_key(.LEFT_CONTROL,true),smoke_key(.S,true))
 sandbox_smoke_frame(&g,target,smoke_key(.LEFT_CONTROL,false),smoke_key(.S,false))
 path:=fmt.aprintf("%s/layout-001.json",directory); defer delete(path)
 assert(os.is_file(path))
 example,eok:=encode_layout(&g.layout,g.world.settings.seed); assert(eok)
 assert(os.write_entire_file("evidence/material-library/custom-layout.json",example)==nil); delete(example)
 sandbox_smoke_click(&g,target,1040,43); sandbox_smoke_click(&g,target,640,392)
 assert(!g.panel_open && g.editor.editing && len(g.layout.materials)==4 && len(g.layout.objects)==4)
 // Native right-click removes the referencing object, then Delete succeeds.
 p=screen_point(sandbox_view(1280,800),{0.7,0.7})
 sandbox_smoke_frame(&g,target,smoke_mouse(i32(p.x),i32(p.y)),rl.AutomationEvent{type=6,params={1,0,0,0}})
 sandbox_smoke_frame(&g,target,rl.AutomationEvent{type=5,params={1,0,0,0}})
 assert(len(g.layout.objects)==3)
 sandbox_smoke_click(&g,target,930,43); sandbox_smoke_click(&g,target,340,406); sandbox_smoke_click(&g,target,640,595)
 assert(len(g.layout.materials)==3)
 assert(g.autosaved_layout_revision==g.layout_revision)
 fmt.println("Native material smoke passed: duplicate, text rename, slider, swatch, keys 5-8, place, Test/blast/Edit, blocked/allowed deletion, Ctrl+S, load, autosave; minimum width 900")
}

