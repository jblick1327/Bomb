# BOM material library

Implemented layout-owned custom materials, the Materials modal, eight palette buttons/shortcuts, twelve colour swatches, atomic validation, autosave, version-1 loading and version-2 layout files. Custom recipes inherit their base family; toughness scales both strengths. Used customs append in palette order after the unchanged ground Stone and four built-in records, as approved. Custom names are independently owned by the layout and World. Mortar rules and strengths are unchanged.

Checks 1–5 passed **before** the final Wood change: all **23 existing standard fixtures** and **25 additional fixture/preset captures**, including all five presets, were byte-identical; the 150-test suite passed with leak failures enabled. Four customs round-trip to identical layout and World bytes. Duplicate names, invalid ranges/RGB/base/references and a fifth custom are rejected atomically. Native automation exercised the actual name textbox, sliders, swatches, placement, Test/blast/Edit, blocked and allowed deletion, save/load, autosave and modal blocking/Tab/Escape. Native teardown: Odin **0**, Box2D **0**. Actual 4× MSAA: **0 seam defects**.

The final build passes **152 tests** with leak failures enabled; the strengthened knob check also confirms the Rubber fixture has no breaks and zero final cell speed. Final native smoke and MSAA checks pass again. Evidence includes raw logs, exact fixture bytes, a comparison manifest and an example [version-2 layout](evidence/material-library/custom-layout.json).

| Knob comparison | Measured result |
|---|---|
| Wood toughness 1 → 2 | Lost area **0.960075 → ~0** (pre-final default: 0.917228 → 0) |
| Wood thickness 0.3 → 0.15 | Maximum built width **0.200000 → 0.117176**; blasted-cell median width **0.200000 → 0.107846** |
| Glass shock loss 4 → 2 | Largest-piece fraction **0.727691 → 0.020877** |
| Stone resistance 3 → 6 | Wood lost area **0.121396 → ~0** (pre-final: 0.119495 → ~0) |
| Rubber flexibility 0.5 → 0.25 | Rest sag **0.252513 → 0.068255** |

Fixture choices: seed 42 throughout, immediate blasts. Toughness: Wood (0,0)–(6,0.8), blast (-0.1,0.4), radius 4. Thickness: (0,0)–(6,0.2), same blast; the shorter height exercises 0.15 within the existing 0.1 minimum-width rule (the 0.8-high version retains an unsplittable 0.196 cell). Glass: (0,0)–(5,2.5), blast (-0.6,1.25), radius 3. Cover: Stone (2,0)–(2.2,2.4), Wood (2.2,0)–(3.2,1.6), blast (1,1), radius 4.8; thinner wall and adjacent Wood avoid both variants being fully protected. Rubber: (0,1)–(1.6,1.4), two Stone supports (0,0)–(0.4,1) and (1.2,0)–(1.6,1), all mortar-enabled, 600 ticks. An unsupported long span fell to the floor, so the supported short span measures sag at rest. Near-zero areas are f32 rounding.

After those checks, built-in Wood changed from **0.3 to 0.2**. Missing snapshot thickness still means **0.3**; the new 0.2 value is explicit. Snapshots omit legacy-default thickness/colour. The `COVER_SHORTCUTS` compile switch is deleted, retaining its former default path. All 48 captures were re-baselined; [counts and hashes](evidence/material-library/fixture-comparison.json) record the changes. The cleanup fixture changed from 0.3×0.3 to 0.2×0.2 to retain its one-cell purpose. The long-cell assertion uses seed 47 (29 cells), because seed 42 now has one 0.9429-long cell; no generation or failure rule was changed.

| Wood study, before → after | Result |
|---|---|
| Built 6×0.8 plank, seed 42 / identity 1 | **20 → 28 cells** |
| 16 seeds, pooled ≥3:1 share | **100% → 100%** |
| Median width / length | **0.13441455 / 0.78179264 → 0.13440832 / 0.79462373** |
| Mean crater area | **6.88093281 → 6.59263611** |
| Median worst blast_pass, 3 runs | **25.5393 → 26.8074 ms** (+5.0%) |

The Wood study retains seeds 1–16, a 6×4 piece and blast (-0.1,2), radius 5. Each timing run simulates 20 minutes at 60 Hz, four 1.6×2 materials, seed 42, falling bombs, radius 5 and two-minute refills. Three original runs then three final runs ran sequentially without competing builds/tests. Worst passes: before **22.9047, 25.5393, 26.3171 ms**; after **32.2200, 26.8074, 25.9014 ms**. All six teardown checks report zero Odin/Box2D bytes. Earlier concurrent timings were replaced.

PNGs: [Materials / custom Wood](evidence/material-library/materials-panel.png), [all eight entries at 900 px](evidence/material-library/edit-eight-materials.png), [custom colours after a blast](evidence/material-library/test-custom-blast.png).

Reproduce: `scripts/bom.ps1 Test`, `scripts/bom.ps1 SmokeMaterials`, optimized `odin build src -o:speed`, then `--wood-study`, `--glass-study`, `--soak-fixture`, `--smoke-msaa` and three `--soak 20` runs. Original and pre-default-change source archives are retained under `evidence/material-library/`.
