package main

import "core:fmt"
import "core:os"
import "core:strconv"

main :: proc() {
	if err:=os.make_directory_all("output"); err!=nil {
		fmt.eprintln("Could not create output directory:",err)
		os.exit(1)
	}
	for arg,i in os.args[1:] {
  if arg=="--wood-study" || arg=="--capture-wood" {
   directory:=string("output/wood-splinters"); if i+2<len(os.args) { directory=os.args[i+2] }
   if arg=="--wood-study" { run_wood_study(directory) } else { run_wood_captures(directory) }; return
  }
  if arg=="--capture-rubber-band" {
   directory:=string("output/rubber-band"); if i+2<len(os.args) { directory=os.args[i+2] }
   run_rubber_band_capture(directory); return
  }
		if arg=="--bench-presentation" { run_presentation_bench(); return }
		if arg=="--smoke-editor" { run_sandbox(true,false,false,false,true); return }
  if arg=="--measure-world" { run_world_measurements(); return }
		if arg=="--soak" {
			minutes:=20
			if i+2<len(os.args) { n,ok:=strconv.parse_int(os.args[i+2]); if !ok || n<1 { fmt.eprintln("--soak expects positive whole minutes"); os.exit(1) }; minutes=n }
			run_soak(minutes); return
		}
		if arg=="--soak-fixture" {
			prefix:=string("output/soak-fixture"); if i+2<len(os.args) { prefix=os.args[i+2] }; run_soak_fixtures(prefix); return
		}
		if arg=="--smoke-msaa" { run_sandbox(true,false,true); return }
  if arg=="--smoke-aim" { run_sandbox(true,false,false,true); return }
		if arg=="--smoke" { run_sandbox(true); return }
		if arg=="--smoke-input" { run_sandbox(true,true); return }
		if arg=="--help" { fmt.println("odin run src -out:build/BOM.exe -- [--soak [minutes] | --soak-fixture [output-prefix] | --bench-presentation | --measure-world | --wood-study [directory] | --capture-wood [directory] | --capture-rubber-band [directory] | --smoke-msaa | --smoke-aim | --smoke-editor | --smoke | --smoke-input | --help]"); return }
	}
	if err:=os.make_directory_all("layouts"); err!=nil { fmt.eprintln("Could not create layouts directory:",err); os.exit(1) }
	run_sandbox()
}

