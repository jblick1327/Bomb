# Wood splinters

Implemented grained recipes only (`aspect_ratio < 1`): 0.3-thick creation strips with a 2.0 length cap, thickness-first failures, slanted cross-cuts, alternating jagged seams and nearest-boundary bond blast sampling. Shared segments are derived, excluded from JSON, rebuilt on decode and freed with their connections. Strengths, recipes, blast/impact laws, welds, player tuning and the physics step are unchanged. No commit was made.

| Check | Before | After |
| --- | ---: | ---: |
| 1. Editor-built 6×0.8 plank, seed 42: cells | 47 | 20 |
| Cells shorter than 1.0 | 47 | 0 |
| Cells thicker than 0.3 / longer than 2.0 | 0 / 0 | 0 / 0 |
| 3. Long along-grain seams with fewer than 2 displaced interior vertices | 20 of 20 | 0 of 15 |
| 5. Premature cross-cut children while thinning fits | 2 | 0 |
| Children from a finished 0.8×0.15 strip | 2 | 0 |
| Long bond peels from a blast near its end | 0 | 1 |

These checks ran against the original build before implementation. This checkout measured **47**, rather than the prompt's 46, using editor identity 1 and yard seed 42. No seed or geometry was adjusted to match that estimate. The original direct-root seed-42 probe gives 42 cells; the reported plank uses the editor path throughout.

**2. Sixteen-seed grain study:** root seeds 1–16, 6×4 Wood, radius 5 at (-0.1,2), no ticks. Statistics pool surviving logical cells outside the largest remaining piece by mass. Length/width are the larger/smaller rest bounding extents; crater area and thrown mass are per-seed means. Thrown mass is surviving area outside that piece immediately after the blast.

| Metric | Before | After |
| --- | ---: | ---: |
| Fragments sampled | 394 | 311 |
| Share ≥3:1 | 66.2437% | 100.0000% |
| Share <1.6:1 | 0.0000% | 0.0000% |
| Median length | 0.466342 | 0.781793 |
| Median width | 0.134956 | 0.134415 |
| Crater area | 6.923342 | 6.880933 |
| Thrown mass | 1.586908 | 1.481482 |

**3–5. Geometry, identity and verification:** all existing 32-seed checks pass: simple polygons, minimum width, collision fixtures and render fills matching their area. The combined floor/Glass/Stone/Rubber fixture after three blasts is byte-identical: **259,273 bytes**, SHA-256 `ada563fab1f4f72f25475fdda63dda4c157e63d1f6c233cfcc5fae0f6867a88b`. The mixed fixtures intentionally change and are re-baselined as `after-v3-blasts.json` (249,415 bytes) and `after-v3-ticked.json` (302,691 bytes); two same-process 600-tick replays agree exactly. Full fixture hashes are in [verification.json](evidence/wood-splinters/verification.json).

**123 tests pass**, with allocation tracking enabled and no leak reports. Grain/pre-split checks now distinguish creation limits, legal thinning, the 8:1 cross-cut threshold and genuinely finished cells. The editor reset test compares descendant contexts instead of assuming an unrefined Wood root. Derived boundary reconstruction has 0 bit mismatches; rotated/translated sampling checks 80 actual jagged vertices. MSAA interior, floor, glass and rubber-film defects remain **0 → 0**. Native input and editor smokes pass; editor teardown is 0 Odin bytes / 0 additional Box2D bytes.

**6. Physics sanity:** every preset retains its tick-0 region/link counts through all 600 idle ticks. Whole-piece rotation stays below 10°. No preset coordinates changed.

| Preset | Regions, tick 0 → 600 | Links, tick 0 → 600 | Maximum whole-piece rotation |
| --- | ---: | ---: | ---: |
| Materials | 233 → 233 | 510 → 510 | 1.820673° |
| Tower | 184 → 184 | 417 → 417 | 0.023043° |
| Glass house | 183 → 183 | 423 → 423 | 0.151994° |
| Rubber pad | 185 → 185 | 425 → 425 | 0.706466° |

Three serial **20-minute** seed-42 falling-bombs soaks per build, optimized with `-o:speed`, with the ordinary two-minute refills and allocation tracking. No tests or graphics runs overlapped these measurements. Worst `blast_pass` times per run: before **14.6008 / 14.6581 / 19.2049 ms**; after **16.1036 / 14.6660 / 13.3115 ms**. Median worst blast: **14.6581 → 14.6660 ms**. All six runs finish with **0 Odin bytes and 0 Box2D bytes**; stored/live region, link and piece counts match at every minute.

Requested width-2 PNGs, captured from the actual 4× MSAA framebuffer with identical before/after cameras:

| Scene | Before | After |
| --- | --- | --- |
| Built plank (F3 regions shown to expose its cuts) | [PNG](evidence/wood-splinters/before/plank-2.png) | [PNG](evidence/wood-splinters/after/plank-2.png) |
| Seed-42 Wood 6×4, 120 settle ticks, blast at (-0.1,2), paused immediately | [PNG](evidence/wood-splinters/before/wood-blast-2.png) | [PNG](evidence/wood-splinters/after/wood-blast-2.png) |
| Tower, radius 5 at (0.2,1.6), 60 ticks later | [PNG](evidence/wood-splinters/before/tower-2.png) | [PNG](evidence/wood-splinters/after/tower-2.png) |

Reproduce with `odin test src`, and executable flags `--wood-study [directory]`, `--capture-wood [directory]`, `--soak-fixture [prefix]`, `--smoke-msaa`, and `--soak 20`. Raw logs and per-seed snapshots accompany the report. `odin check src` and `git diff --check` pass.
