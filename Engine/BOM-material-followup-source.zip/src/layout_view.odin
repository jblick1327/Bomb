package main

import rl "vendor:raylib"
import "core:fmt"
import "core:os"
import "core:strings"

sandbox_draw_layouts_panel :: proc(game: ^Sandbox,width,height: f32) -> Sandbox_UI_Action {
	rl.DrawRectangle(0,0,i32(width),i32(height),{8,14,23,205})
	x,y:=(width-640)*0.5,(height-560)*0.5
	rl.DrawRectangleRounded({x,y,640,560},0.025,8,{23,35,49,255})
	x+=28; y+=24
	rl.DrawText("LAYOUTS / PAUSED",i32(x),i32(y),24,YARD_INK)
	if rl.GuiButton({x+480,y-3,104,32},"Close") { return .Resume }
	y+=50
	rl.DrawText("PRESETS",i32(x),i32(y),17,YARD_ACCENT)
	button_width:=f32(584-8*(len(PRESET_NAMES)-1))/f32(len(PRESET_NAMES))
	for name,i in PRESET_NAMES {
		if rl.GuiButton({x+f32(i)*(button_width+8),y+24,button_width,30},rl.TextFormat("%s",name)) { sandbox_load_preset(game,i); return .None }
	}
	y+=66
	if rl.GuiButton({x,y,584,36},"Save current layout  /  Ctrl+S") { sandbox_save_current_layout(game) }
	y+=55
	rl.DrawText("SAVED",i32(x),i32(y),17,YARD_ACCENT)
	y+=28
	if game.last_session {
		if rl.GuiButton({x,y,584,30},"Last session") {
			path:=fmt.aprintf("%s/autosave.json",game.layout_directory); defer delete(path)
			sandbox_load_layout_file(game,path); return .None
		}
		y+=34
	}
	for file in game.layout_files {
		_,name:=os.split_path(file.path)
		if rl.GuiButton({x,y,584,30},rl.TextFormat("%s",name)) { sandbox_load_layout_file(game,file.path); return .None }
		y+=34
	}
	rl.DrawText("Drop a layout .json onto the window to load it",i32(x),i32((height+560)*0.5-32),16,YARD_MUTED)
	return .None
}
sandbox_layout_file_input :: proc(game: ^Sandbox) -> bool {
	if rl.IsFileDropped() {
		files:=rl.LoadDroppedFiles(); defer rl.UnloadDroppedFiles(files)
		paths:=files.paths[:files.count]
		if index:=sandbox_dropped_layout_index(paths); index>=0 { sandbox_load_layout_file(game,string(paths[index])); return true }
	}
	if game.editor.editing && !game.panel_open && (rl.IsKeyDown(.LEFT_CONTROL) || rl.IsKeyDown(.RIGHT_CONTROL)) && rl.IsKeyPressed(.S) {
		sandbox_save_current_layout(game); return true
	}
	return false
}
sandbox_dropped_layout_index :: proc(paths: []cstring) -> int {
	for path,i in paths {
		name:=string(path)
		if len(name)>=5 && strings.equal_fold(name[len(name)-5:],".json") { return i }
	}
	return -1
}
