package main

import rl "vendor:raylib"

editor_screen_rect :: proc(view: View,r: Authored_Rect) -> rl.Rectangle {
	lo,hi:=screen_point(view,{r.lo.x,r.hi.y}),screen_point(view,{r.hi.x,r.lo.y})
	return {lo.x,lo.y,hi.x-lo.x,hi.y-lo.y}
}
sandbox_draw_editor :: proc(game: ^Sandbox,view: View) {
	if !game.editor.editing { return }
	area:=editor_screen_rect(view,Authored_Rect{lo={-7.5,0},hi={8.5,4.8}})
	rl.DrawRectangleLinesEx(area,1,{144,165,178,65})
	for object in game.layout.objects {
		box:=editor_screen_rect(view,object)
		material:=layout_material(&game.layout,object.material)
		rl.DrawRectangleRec(box,material_color(material))
  if object.mortar { inner:=box; inner.x+=3; inner.y+=3; inner.width-=6; inner.height-=6; rl.DrawRectangleLinesEx(inner,3,MORTAR_COLOR) }
		if game.outline_width>0 { rl.DrawRectangleLinesEx(box,game.outline_width,YARD_INK) }
		rl.DrawText(rl.TextFormat("%s",material.name),i32(box.x)+5,i32(box.y)+5,16,YARD_INK)
	}
	if game.editor.dragging {
		r:=editor_rectangle(game.editor.start,game.editor.cursor,game.editor.palette)
		box:=editor_screen_rect(view,r)
		color:=rl.Color{111,220,190,100}
		problem:=editor_rectangle_problem(&game.layout,r)
		if problem!="" { color={244,132,131,100} }
		rl.DrawRectangleRec(box,color); color.a=255
		rl.DrawRectangleLinesEx(box,2,color)
		label:=rl.TextFormat("%.1f Ã— %.1f",r.hi.x-r.lo.x,r.hi.y-r.lo.y)
		x:=clamp(box.x+box.width+12,f32(12),f32(rl.GetScreenWidth()-240))
		y:=clamp(box.y,f32(98),f32(rl.GetScreenHeight()-130))
		rl.DrawText(label,i32(x),i32(y),20,color)
		if problem!="" { rl.DrawText(rl.TextFormat("%s",problem),i32(x),i32(y)+26,16,color) }
	}
}
sandbox_editor_input :: proc(game: ^Sandbox,point: Vec2,over_ui: bool) {
	if game.panel_open { game.editor.dragging=false; return }
 if rl.IsKeyPressed(.M) { game.editor.mortar=!game.editor.mortar }
	keys:=[8]rl.KeyboardKey{.ONE,.TWO,.THREE,.FOUR,.FIVE,.SIX,.SEVEN,.EIGHT}
	for key,i in keys { if i<palette_count(&game.layout) && rl.IsKeyPressed(key) { game.editor.palette=Slot(i) } }
	if rl.IsMouseButtonPressed(.RIGHT) && !over_ui {
		game.editor.dragging=false
		editor_remove(game,point)
	}
	if rl.IsMouseButtonPressed(.LEFT) && !game.block_blast && !over_ui {
		game.editor.dragging=true; game.editor.start=editor_snap(point)
	}
	if game.editor.dragging {
		game.editor.cursor=editor_snap(point)
		if rl.IsMouseButtonReleased(.LEFT) {
			if !over_ui { editor_place(game,game.editor.start,game.editor.cursor) }
			game.editor.dragging=false
		}
	}
}
