# BOM material library follow-up

Implemented the requested range and representation fixes. `STRIP_MIN = 2 * WOOD_MINIMUM_WIDTH = 0.2` is shared by validation, the slider and its error text. Layout decoding rejects 0.15 atomically, without clamping; the new regression failed on the accepted build and passes now. Generation arithmetic and partition rules are unchanged.

`Recipe` contains only Wood/Glass/Rubber/Stone. Authored references and palette controls use `Slot`, a distinct integer. Reverse lookup visits valid Recipe members; there are no integer-to-Recipe casts. Built-in colours are explicit in PALETTE_MATERIALS. Material RGB is a plain array, rendering uses that value, and strip targets are explicit (Wood 0.2, custom Wood's value, non-grained materials 0). The private name-colour lookup and missing grained-strip default 0.3 exist only in snapshot encoding/decoding. Non-grained snapshot materials reject a present strip field. Encoding keeps the accepted omission rules.

Before-change check a was measured in native Odin and is retained only as a report/log, not a test. **The outlines were not identical**, contrary to the expected result:

| Pre-change 6×0.8 plank | Strip 0.12 | Strip 0.2 |
|---|---:|---:|
| Layout seed 42, object identity 1: cells | 15 | 28 |
| Maximum built width | 0.19617306 | 0.19617306 |
| Direct piece seed 42: cells | 13 | 23 |
| Maximum built width | 0.21775562 | 0.21775562 |

Both seed conventions were checked to remove ambiguity. Width is the shorter axis-aligned bounding extent, as in the existing Wood study. The native generator can block an impossible thickness cut before trying a length cut; equal maximum widths do not establish identical outlines. No generation rule was changed to obtain the expected result.

Replacement check c uses the normal editor build: layout seed 42, object identity 1, rectangle (0,0)–(6,0.8), no blast. Strip **0.2** builds **28 cells**, maximum width **0.19617306 ≤ 0.2**. Strip **0.4** builds **20 cells**, maximum width **0.28363450 > 0.2**. This replaces the old 0.2-high special-case fixture; no further geometry or seed adjustment was needed.

All **48/48 accepted captures are byte-identical**, including all five presets and the 600-tick replay. [The manifest](byte-identity-manifest.json) lists byte counts and matching before/after SHA-256 hashes for every file; no baseline was rewritten. The pre-library v3 snapshot `evidence/world-v3/continuity-manual-S.json` decodes/re-encodes to its exact **266,812 bytes**. It replaces the suggested `before-v2-ticked.json` as the v3 fixture because that file is a v2 Scene snapshot.

**155 tests pass** with leak failures enabled. Native Materials smoke verifies both slider endpoints (0.2 and 0.6), all eight palette shortcuts, edit/test, validation, save/load and teardown: **Odin 0; Box2D delta 0**. Actual 4× MSAA still has **0 interior defects**. No new soak was needed: simulation output and all accepted fixture bytes are unchanged.

Reproduce: `scripts/bom.ps1 Test`; `scripts/bom.ps1 SmokeMaterials`; optimized build plus `--wood-study`, `--glass-study`, `--soak-fixture`, `--smoke-msaa`; then `python scripts/package-material-followup.py`. Source archive includes the before-change log, final logs, all 48 before/after capture pairs, and both required legacy snapshot fixtures. No PNGs or binaries are included.
