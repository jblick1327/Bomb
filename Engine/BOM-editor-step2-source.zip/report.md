# BOM Step 2 — editor, layouts and presets

Completed A → B → C → D, verifying each before proceeding. Odin + Box2D 3.1.1 + raylib 5.5. No strengths, recipes, damage laws, welds, player tuning or physics-step changes; no commit.

## Existing-behaviour checks: before → after

| Check | Current-build baseline | Final |
| --- | ---: | ---: |
| A1 queued radius versus applied radius: differing HUD pixels | 24 | 0 |
| A1 same comparison: differing aim pixels | 3,740 | 0 |
| A2 adaptive segment cases, radii 10/300/1,000 px | 3 failures / 3 | 0 / 3 (48/100/256 segments) |
| A3 promoted `using world: World` declarations | 1 | 0 |
| A3 lazy World cache records written while drawing a fresh editor | 153 | 0 |
| A4 active Odin files containing CRLF | 39 | 0 |
| B direct `editor_place` off-grid endpoint mismatches | 0 | 0 |
| C runtime filesystem call sites in unit tests | 3 | 0; legacy fixture embedded with `#load` |

The A1 native check renders pending radius 2 and applied radius 2 without advancing physics, comparing both HUD and aim pixels. Aim rings use `DrawRing`, 1.5 px thick, with unchanged colours/alphas. Interactive drawing requires caches prepared inside tick/build/load; it has no lazy cache-write fallback.

**A3 mutation-site list: empty.** No production frame-side World-field writes occur outside `world_tick` or build/replace/load paths. Reset/toggle construction, layout replacement (including its seed), snapshot replacement and teardown retain their normal ownership duties. Direct fixture helpers and tests remain separate from the interactive input path. Every Sandbox World access is explicit through `.world`.

## New editor and layout checks

- Snap `{7.23,-5.649}` → `{7.2,-5.6}`: bitwise equal to f32 literals (`40e66666`, `c0b33333`). Rounding uses integer indices divided by f32 10; `editor_place` retains exact coordinates.
- Shared-edge test uses the approved correction **1.02 / 1.04**. Unsnapped gap: **0.019999981** (nominally 0.02); snapped gap: **0**, with both edge bits `3f800000`. Both rectangles validate. The original 1.04/1.06 pair straddled a rounding midpoint.
- Rectangle problems: all four specified reasons and valid → empty string pass. Native number keys 1–4, snapped mouse preview, dimensions and invalid-placement notice pass.
- Layout round trip: **0 float/identity/counter/seed mismatches**, identical re-encoding. Original and decoded layouts build identical v3 World bytes using matching build revisions. Identities 23/91, next identity 102 and seed 233 are exercised. The counter now denotes the next free identity; generated object identities remain unchanged.
- **12/12** invalid layouts rejected, **12/12** leave Layout and World unchanged: wrong kind/version, unknown material, zero/duplicate identity, invalid next identity, each rectangle reason, malformed JSON and seed outside 0–255. The first problem is shown.
- First dropped JSON selection, including uppercase `.JSON`, passes. The native drop handler uses raylib's dropped-file list and releases it.
- Native Layouts smoke passes: open/Tab/Escape, underlying input consumption, Save button, exact saved-file reload, Ctrl+S, newest eight of ten saves, Last session, autosave on placement/removal/load/preset, startup restoration and Test → Edit load. Smoke I/O uses unique `output/` folders; constructors and unit tests do no runtime file I/O.

New features did not require failing baselines. Evidence logs retain the existing-behaviour before runs.

## Presets: 600 idle ticks, seed 42, no blasts

All four embedded JSON files decode/validate and retain listed identities. Materials builds **byte-identically to `soak_yard`**, with no snapshot normalization. **No preset coordinates changed.** Every tick retains its initial live region/link counts.

| Preset | Regions, initial → final | Links, initial → final | Maximum whole-piece rotation over 600 ticks | Largest rubber-cell rotation relative to its piece at tick 600 |
| --- | ---: | ---: | ---: | ---: |
| Materials | 256 → 256 | 571 → 571 | 1.820673° | 4.585706° (20 cells) |
| Tower | 195 → 195 | 446 → 446 | 0.068074° | N/A: no rubber |
| Glass house | 194 → 194 | 448 → 448 | 0.151994° | 0.012435° (4 cells) |
| Rubber pad | 183 → 183 | 423 → 423 | 0.687806° | 9.471310° (26 cells) |

As clarified, the 10° limit applies to whole-piece rotation: rigid body angle for rigid pieces; area-weighted best-fit rotation of rest/posed cell centres for flexible pieces. The last column is informational, using each rubber cell's angle minus its piece's fitted angle, wrapped to ±π. An initial diagnostic incorrectly bounded every cell over the entire run; it found transient 40.115913° local bending in Materials. Measuring whole-piece rotation resolves that distinction without altering physics or coordinates.

## Verification and deliverables

| Gate | Tests | Blast-only / 600-tick v3 fixtures |
| --- | ---: | --- |
| Before | 103 pass | Baseline captured |
| A | 103 pass | Both byte-identical |
| B | 106 pass | Both byte-identical |
| C | 109 pass | Both byte-identical |
| D / final | **111 pass** | **Both byte-identical** |

Allocation tracking reports **no unit-test leaks**. Final native editor smoke leaves **0 Odin bytes / 0 additional Box2D bytes**. Existing native input smoke passes; MSAA interior defects remain **0**, including glass (58 live crack boundaries, 0 bright pixels). `odin check src` and `git diff --check` pass. Each fixture run also checks two sequential same-process 600-tick replays for identical bytes. Fixture hashes and unchanged simulation-file comparisons are in `evidence/editor-step2/verification.json`.

Reproduce with `odin test src -o:speed -out:build/BOM-tests.exe`, `scripts/bom.ps1 Build`, then `build/BOM.exe --smoke-editor`, `--smoke-input`, `--smoke-msaa`, or `--soak-fixture output/check`. Main creates interactive `layouts/` beside `output/`; authored files are separate from F3 World snapshots.

Source: [BOM-editor-step2-source.zip](BOM-editor-step2-source.zip). PNGs:

- [Materials — Test, tick 0](evidence/editor-step2/preset-1.png)
- [Tower — Test, tick 0](evidence/editor-step2/preset-2.png)
- [Glass house — Test, tick 0](evidence/editor-step2/preset-3.png)
- [Rubber pad — Test, tick 0](evidence/editor-step2/preset-4.png)
- [Edit mid-drag — dimensions and invalid reason](evidence/editor-step2/edit-invalid-drag.png)
