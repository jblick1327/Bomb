# BOM mortar

Parts A, B and C are complete. No existing strengths, recipes, blast/impact laws, glass shock, wood rules, rubber weld parameters, player tuning or physics step changed. No commit made.

## Part A

| Check | Result |
| --- | --- |
| A1: two mortared Stone blocks | 1 facing pair + 6 floor pairs (6 expected). Different pieces; no mortar in piece.connections; scene valid. |
| A2: blast breaks mortar without regrouping blocks | At (1,3), radius 5: seam load 25, maximum block cell load 24.504902 < Stone subdivision strength 35. Facing mortar removed; both block cells and piece IDs unchanged. |
| A3: weld re-attachment | Break 3 internal bonds around the mortared beam cell: 2 beam pieces; the supported cell moves off B0. All live mortar joints valid and their bodies match the cells. Scene valid. Over 60 ticks, maximum drop 0.002561212 m; a re-created support weld remains live (1 of 2 original support welds survives). Force breaking stays enabled. |
| A4: World snapshot | Mortar plus overload_ticks=2: encode/decode/re-encode identical bytes; decoded non-static mortar joints exist with correct body endpoints. |
| A5: layout and construction ranges | Mortar flag round-trips; old layout defaults false. Every authored object and ground has non-empty sorted cell ranges with live current owners in all 5 presets. |
| A6: shock isolation | Pane B retains all 100 original cells after the blast cracks adjoining pane A. Scene validates. |
| A7: regressions | All 23 baseline fixture files identical after EACH part; new optional connection fields absent without mortar. Existing 129 test sources and the original 4 preset files unchanged. |

Fixture adjustments: the original A3 blast could deliver at most load 17, below Wood bond/subdivision strengths 22/28. The prescribed centre-x discard removed one cell but left one connected beam piece. The final editor fixture uses Stone (-0.4,0) to (0.8,1), Wood (0,1) to (4,1.4), both mortar, seed 42. Three bonds crossing from the mortared cell to other beam cells are broken through one Failures.connections batch. The support was widened from (0,0)–(0.4,1) because that fixture dropped 0.127463 m with force breaking enabled. These are fixture changes only. The standing fixture policy is saved in AGENTS.md.

## Part B

Calibration uses the specified F1/F2 coordinates, seed 42, force breaking disabled, and every valid mortar joint sampled over ticks 60–120 inclusive.

| Fixture | N |
| --- | ---: |
| F1, 2.4 m beam | 375.444732666 |
| F2, 4.4 m beam | 1268.447143555 |

N(F2)/N(F1) = 3.378519058 > 2. Geometric mean = 690.095520020; **MORTAR_STRENGTH = 690** (two significant digits). The controlling seam is 0.167579323 m long; the other beam-support seam is 0.232420683 m. The floor seam is 0.4 m. Capacity and overload filtering follow the specification.

With breaking enabled: F1 holds 600 ticks with **0 breaks**. F2 first breaks at **tick 2**; its lowest wood-cell centre crosses y=1.0 at **tick 32** (3 joints broken by tick 240). Part A checks still pass.

## Part C

Bridge uses the original coordinates: **no changes**. Through 600 idle ticks: 0 force breaks; regions 272 -> 272, links 592 -> 592, pieces 5 -> 5, mortar 6 -> 6. All five presets settle without count changes; Bridge maximum piece rotation is 0.001662°.

Radius-5 blast at (-3,1), starting at tick 0: the blast retires **2 mortar connections**, with no inherited replacements (6 -> 4 live). During the next 180 ticks, **4 more break by force** (4 -> 0). The deck's lowest vertex crosses y=1.0 at **tick 93**; minimum y over the run is -0.000129715. This measurement is report-only; no tuning followed it.

## Verification and artifacts

**135 tests pass**, including all 129 pre-existing tests, with allocation tracking and no leak reports. The strengthened A3 support-weld survival assertion also passes. Native input, editor, five preset buttons, M key/toggle and modal blocking pass. Editor smoke teardown: Odin bytes 0, Box2D delta 0; capture teardown: Box2D bytes 0.

Actual 4× MSAA defects remain **0**, including floor, glass cracks and rubber film. Glass crack guard: 337 boundaries. Drawing the captures leaves World snapshot bytes unchanged. odin check src and source archive checks pass.

Four PNGs, outline width 2, actual-MSAA default framebuffer (1600×1000, logical 1280×800):

- [Bridge, tick 0](evidence/mortar/pngs/bridge-tick-0.png)
- [Bridge, 90 ticks after blast](evidence/mortar/pngs/bridge-blast-90.png)
- [F2, tick 120](evidence/mortar/pngs/f2-tick-120.png)
- [Edit mode, two mortar objects and toggle](evidence/mortar/pngs/edit-mortar.png)

Raw results and all 69 per-part fixture comparisons are in evidence/mortar/. Reproduce calibration with `odin run src -- --calibrate-mortar`; Bridge force counts with `odin run src -define:BOM_MORTAR_MEASURE=true -- --measure-mortar`; captures with `odin run src -- --capture-mortar output/mortar`. The measurement-only counter is compiled out by default.
