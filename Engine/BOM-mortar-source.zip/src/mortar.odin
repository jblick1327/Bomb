package main

import "core:math"
import b2 "vendor:box2d"
import rl "vendor:raylib"

Built_Object :: struct { identity: u64, mortar: bool, lo,hi: Vec2, first_id,end_id: u64 }
MORTAR_STRENGTH :: f32(690)
MORTAR_COLOR :: rl.Color{236,226,198,255}
mortar_length :: proc(c: Connection) -> f32 {
 result:f32; for segment in c.rest_segments { result+=vlen(vsub(segment.b,segment.a)) }; return result
}
mortar_local_anchor :: proc(s: ^Scene,sub: Subdivision,rest_point: Vec2) -> Vec2 {
 if s.materials[sub.material].flexibility==0 { return rest_point }
 return vsub(rest_point,sub.rest_center)
}
object_cells :: proc(s: ^Scene,obj: Built_Object) -> [dynamic]u64 {
 result:[dynamic]u64
 for sub in s.subdivisions { if sub.live && obj.first_id<=sub.id && sub.id<obj.end_id { append(&result,sub.id) } }
 sort_ids(result[:]); return result
}
mortar_touch :: proc(a,b: Built_Object) -> bool {
 return ((a.hi.x==b.lo.x || b.hi.x==a.lo.x) && min(a.hi.y,b.hi.y)-max(a.lo.y,b.lo.y)>0) ||
        ((a.hi.y==b.lo.y || b.hi.y==a.lo.y) && min(a.hi.x,b.hi.x)-max(a.lo.x,b.lo.x)>0)
}
mortar_bounds :: proc(p: Polygon) -> (lo,hi: Vec2) {
 lo={1e30,1e30}; hi={-1e30,-1e30}
 for v in p.points { lo={min(lo.x,v.x),min(lo.y,v.y)}; hi={max(hi.x,v.x),max(hi.y,v.y)} }; return
}
mortar_cells :: proc(s: ^Scene,cells_a,cells_b: []u64) {
 for a in cells_a { for b in cells_b {
  sa,sb:=s.subdivisions[s.sub_rows[a]],s.subdivisions[s.sub_rows[b]]
  alo,ahi:=mortar_bounds(sa.outline); blo,bhi:=mortar_bounds(sb.outline)
  if ahi.x<blo.x || bhi.x<alo.x || ahi.y<blo.y || bhi.y<alo.y { continue }
  if length,_:=shared_boundary(sa.outline,sb.outline); length>0 { add_connection(s,a,b,true) }
 } }
}
build_mortar :: proc(s: ^Scene,objects: []Built_Object,ground: Built_Object) {
 for i in 0..<len(objects) { for j in i+1..<len(objects) {
  a,b:=objects[i],objects[j]
  if (a.mortar || b.mortar) && mortar_touch(a,b) {
   left,right:=object_cells(s,a),object_cells(s,b)
   mortar_cells(s,left[:],right[:]); delete(left); delete(right)
  }
 } }
 for a in objects { if a.mortar && a.lo.y==0 {
  left,right:=object_cells(s,a),object_cells(s,ground)
  mortar_cells(s,left[:],right[:]); delete(left); delete(right)
 } }
}
draw_mortar :: proc(s: ^Scene,view: View,poses,frames: map[u64]Pose,outline_width: f32) {
 ids:[dynamic]u64; defer delete(ids)
 for c in s.connections { if c.live && c.mortar { append(&ids,c.id) } }; sort_ids(ids[:])
 for id in ids {
  c:=s.connections[s.conn_rows[id]]; sub:=s.subdivisions[s.sub_rows[c.a]]
  rigid:=s.materials[sub.material].flexibility==0
  frame:=rigid_render_frame(s,sub,poses,frames)
  posed:=render_subdivision(s,sub,poses,frames)
  for segment in c.rest_segments {
   a,b:=posed_point(posed,segment.a),posed_point(posed,segment.b)
   if rigid { a=rigid_render_point(frame,segment.a); b=rigid_render_point(frame,segment.b) }
   rl.DrawLineEx(screen_point(view,a),screen_point(view,b),max(f32(2),outline_width),MORTAR_COLOR)
  }
 }
}

mortar_load_ratio :: proc(c: Connection) -> f32 {
 length:=mortar_length(c)
 force:=vlen(from_b2(b2.Joint_GetConstraintForce(c.joint)))
 torque:=math.abs(b2.Joint_GetConstraintTorque(c.joint))
 return force/(MORTAR_STRENGTH*length)+torque/(0.5*MORTAR_STRENGTH*length*length)
}

