# BOM blast cover performance

**Timing passes. Part 1 passes. Part 2 remains incompletely equivalent:** the 23 fixed fixtures match, but the extended 20-minute trajectory diverges.

Part 1: **23/23 fixtures byte-identical**, with identical same-process replays. Original-piece shadow flags use convex-hull/polygon overlap after bounds rejection; descendants inherit flags. Remaining rays traverse a one-metre snapshot grid, skip their original owner, and sum in cell-ID order. Ray scratch is reused. Exact memoization, failure-load upper bounds, zero-load termination, cached boundaries, failed-partition reuse, stack hulls and generation scratch reduce repeated work. Completed outlines retain owned storage; cache collisions verify full float inputs.

Part 2: **23/23 fixed fixtures match** in the multiset of surviving rest outlines, full pose float bits (including signed zero), and piece partition, ignoring IDs. Seventeen snapshots remain byte-identical; six change IDs. [Per-fixture comparison](fixture-comparison.md) includes every re-baseline.

Literal restoration of the extent-only reach heuristic mismatched five fixtures: blast-only, ticked, non-Glass control, non-Wood control, and radius-3 Glass, with 12, 3, 3, 15 and 3 differing outlines. Disabling new reach pruning removed these mismatches; disabling deletion did not. Extent alone omits the blast-to-cell offset and cannot prove whole-cell erasure. The candidate retains it only in legacy cases and requires the existing farthest-point proof for new cases. Rejected snapshots are retained.

EXTENDED

PERFORMANCE

Wall fixture unchanged: Stone (2,0)-(2.4,2.4), Wood (2.6,0)-(3.6,1.6), seed 42, blast (1,1), radius 5. Wood lost area **0.000000358 m^2** (rounding), **0 failed cells**. The 16-seed Wood mean crater remains **6.88093281 m^2**. Bridge settles 600 ticks without breaks: 272 cells, 592 links, 5 pieces, 6 mortar. C2 removes 2 mortar, then 4 force breaks leave 0. Deck crosses y=1 at tick **98**, minimum y **0.221174106**, matching baseline. No fixture adjustments.

**146 tests pass**, with allocation tracking and no leak reports. Differential checks cover indexed rays, hull storage, scratch generation, cache collisions and zero-load termination. MSAA defects remain **0**. SOAK_LEAKS

Reproduce: `odin build src -o:speed -out:build/BOM.exe`, then three sequential `--soak 20` runs. Profile with `-define:BOM_PROFILE=true`. `-define:COVER_SHORTCUTS=false` selects Part 1. `scripts/compare-cover.py` and `scripts/analyze-cover-extended.py` reproduce both comparisons; raw snapshots and logs are included. Extracted-source `odin check` and archive CRC verification pass.
