| Fixture | Part 1 bytes | Part 2 bytes | Outlines / poses / partition |
|---|---|---|---|
| after-blasts.json | identical | IDs changed | exact / exact / exact |
| after-glass/impact.json | identical | identical | exact / exact / exact |
| after-glass/nonglass-v3.json | identical | IDs changed | exact / exact / exact |
| after-glass/pane-r3.json | identical | IDs changed | exact / exact / exact |
| after-glass/pane-r4.json | identical | IDs changed | exact / exact / exact |
| after-ticked.json | identical | IDs changed | exact / exact / exact |
| after-wood/nonwood-v3.json | identical | IDs changed | exact / exact / exact |
| after-wood/seed-01.json | identical | identical | exact / exact / exact |
| after-wood/seed-02.json | identical | identical | exact / exact / exact |
| after-wood/seed-03.json | identical | identical | exact / exact / exact |
| after-wood/seed-04.json | identical | identical | exact / exact / exact |
| after-wood/seed-05.json | identical | identical | exact / exact / exact |
| after-wood/seed-06.json | identical | identical | exact / exact / exact |
| after-wood/seed-07.json | identical | identical | exact / exact / exact |
| after-wood/seed-08.json | identical | identical | exact / exact / exact |
| after-wood/seed-09.json | identical | identical | exact / exact / exact |
| after-wood/seed-10.json | identical | identical | exact / exact / exact |
| after-wood/seed-11.json | identical | identical | exact / exact / exact |
| after-wood/seed-12.json | identical | identical | exact / exact / exact |
| after-wood/seed-13.json | identical | identical | exact / exact / exact |
| after-wood/seed-14.json | identical | identical | exact / exact / exact |
| after-wood/seed-15.json | identical | identical | exact / exact / exact |
| after-wood/seed-16.json | identical | identical | exact / exact / exact |
