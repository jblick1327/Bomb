package main

import rl "vendor:raylib"
import b2 "vendor:box2d"

Seam_Neighbours :: struct { incident,direct: [dynamic]u64 }
Render_Cache :: struct {
	owner,revision: u64,
 anchored: bool,
	outline: Polygon,
	triangles: [dynamic]int,
 draw_edge: []bool,
	seams: []Seam_Neighbours,
}
release_render_cache :: proc(cache: ^Render_Cache) {
	delete(cache.outline.points); delete(cache.triangles); delete(cache.draw_edge)
	for seam in cache.seams { delete(seam.incident); delete(seam.direct) }
	delete(cache.seams); cache^={}
}
// Geometry tests happen once for this piece topology, never once per frame.
seam_neighbours :: proc(s: ^Scene,sub: Subdivision,rest: Vec2) -> Seam_Neighbours {
	result:=Seam_Neighbours{}
	append(&result.incident,sub.id)
	for head:=0; head<len(result.incident); head+=1 {
		id:=result.incident[head]
		for connection in s.subdivisions[s.sub_rows[id]].incident_links {
			c:=s.connections[s.conn_rows[connection]]
			if !c.live { continue }
			other:=u64(0)
			if c.a==id { other=c.b } else if c.b==id { other=c.a }
			if other==0 { continue }
			a,b:=s.subdivisions[s.sub_rows[id]],s.subdivisions[s.sub_rows[other]]
			if !point_on_boundary(rest,a.outline,b.outline) { continue }
			if id==sub.id { append(&result.direct,other) }
			if !contains_id(result.incident[:],other) { append(&result.incident,other) }
		}
	}
	sort_ids(result.incident[:])
	return result
}
triangle_indices :: proc(outline: Polygon) -> [dynamic]int {
	result: [dynamic]int
	triangles:=triangulate_polygon(outline)
	for triangle in triangles {
		for point in triangle.points {
			for vertex,i in outline.points { if point==vertex { append(&result,i); break } }
		}
		delete(triangle.points)
	}
	delete(triangles)
	return result
}
render_static :: proc(sub: Subdivision) -> bool { return sub.body!=b2.nullBodyId && b2.Body_GetType(sub.body)==.staticBody }
render_together_neighbours :: proc(s: ^Scene,sub: Subdivision) -> [dynamic]u64 {
 candidates: [dynamic]u64
 if s.physics.active {
  lo,hi:=Vec2{1e30,1e30},Vec2{-1e30,-1e30}
  for rest in sub.outline.points { p:=posed_point(sub,rest); lo={min(lo.x,p.x),min(lo.y,p.y)}; hi={max(hi.x,p.x),max(hi.y,p.y)} }
  query:=Blast_Query{ids=make(map[u64]bool)}; defer delete(query.ids)
  box:=b2.AABB{lowerBound={lo.x-0.05,lo.y-0.05},upperBound={hi.x+0.05,hi.y+0.05}}
  _=b2.World_OverlapAABB(s.physics.world,box,b2.DefaultQueryFilter(),blast_query_shape,&query)
  for id in query.ids { if is_live_subdivision(s,id) { append(&candidates,id) } }
 } else { for id in s.pieces[s.piece_rows[sub.owner]].subdivisions { append(&candidates,id) } }
 result:[dynamic]u64
 for id in candidates {
  if id==sub.id { continue }
  other:=s.subdivisions[s.sub_rows[id]]
  together:=sub.owner==other.owner && s.materials[sub.material].flexibility==0
  together=together || render_static(sub) && render_static(other)
  if c,ok:=s.connection_pairs[pair_key(sub.id,id)]; ok { together=together || s.connections[s.conn_rows[c]].live }
  if !together { continue }
  boundaries:=shared_segments(sub.outline,other.outline)
  if len(boundaries)>0 { append(&result,id) }; delete(boundaries)
 }
 delete(candidates); sort_ids(result[:]); return result
}
ensure_render_cache :: proc(s: ^Scene,id: u64) -> ^Render_Cache {
	sub:=&s.subdivisions[s.sub_rows[id]]
	cache:=&sub.render
	revision:=s.pieces[s.piece_rows[sub.owner]].render_revision
	anchored:=render_static(sub^)
 if anchored { revision=s.static_render_revision }
 if cache.owner==sub.owner && cache.revision==revision && cache.anchored==anchored { return cache }
	release_render_cache(cache)
	cache.owner=sub.owner; cache.revision=revision; cache.anchored=anchored
	cache.outline=make_polygon(sub.outline.points)
 neighbours:=render_together_neighbours(s,sub^); defer delete(neighbours)
 for other in neighbours { for rest in s.subdivisions[s.sub_rows[other]].outline.points { insert_boundary_endpoint(&cache.outline,rest) } }
	cache.triangles=triangle_indices(cache.outline)
 cache.draw_edge=make([]bool,len(cache.outline.points))
 for a,i in cache.outline.points {
  b:=cache.outline.points[(i+1)%len(cache.outline.points)]
  cache.draw_edge[i]=true
  for other in neighbours {
   neighbour:=s.subdivisions[s.sub_rows[other]]
   if point_on_boundary(vmul(vadd(a,b),0.5),sub.outline,neighbour.outline) { cache.draw_edge[i]=false; break }
  }
 }
	cache.seams=make([]Seam_Neighbours,len(cache.outline.points))
	if s.materials[sub.material].flexibility>0 { for rest,i in cache.outline.points { cache.seams[i]=seam_neighbours(s,sub^,rest) } }
	return cache
}
cosmetic_seam_point :: proc(s: ^Scene,sub: Subdivision,rest: Vec2,poses: map[u64]Pose,seam: Seam_Neighbours,frames: map[u64]Pose = nil) -> Vec2 {
	if s.materials[sub.material].flexibility==0 { return rigid_render_point(rigid_render_frame(s,sub,poses,frames),rest) }
	self:=render_subdivision(s,sub,poses); point:=posed_point(self,rest)
	flex:=clamp(s.materials[sub.material].flexibility,f32(0),f32(1))
	if flex==0 { return point }
	weighted:=point
	for id in seam.direct { other:=render_subdivision(s,s.subdivisions[s.sub_rows[id]],poses); weighted=vadd(weighted,posed_point(other,rest)) }
	return vadd(point,vmul(vsub(vmul(weighted,1/f32(len(seam.direct)+1)),point),flex))
}
common_seam_point :: proc(s: ^Scene,sub: Subdivision,rest: Vec2,poses: map[u64]Pose,seam: Seam_Neighbours,frames: map[u64]Pose = nil) -> Vec2 {
	if s.materials[sub.material].flexibility==0 { return rigid_render_point(rigid_render_frame(s,sub,poses,frames),rest) }
	if len(seam.incident)>1 {
		for id,i in seam.incident {
			a:=render_subdivision(s,s.subdivisions[s.sub_rows[id]],poses)
			for j in i+1..<len(seam.incident) {
				b:=render_subdivision(s,s.subdivisions[s.sub_rows[seam.incident[j]]],poses)
				if vlen(vsub(posed_point(a,rest),posed_point(b,rest)))>0.001 { return cosmetic_seam_point(s,sub,rest,poses,seam) }
			}
		}
		point:=Vec2{}
		for id in seam.incident { other:=render_subdivision(s,s.subdivisions[s.sub_rows[id]],poses); point=vadd(point,posed_point(other,rest)) }
		return vmul(point,1/f32(len(seam.incident)))
	}
	return cosmetic_seam_point(s,sub,rest,poses,seam)
}
// Single-point helpers also serve inspection/tests; draw_scene uses cached seams.
cosmetic_point :: proc(s: ^Scene,sub: Subdivision,rest: Vec2,poses: map[u64]Pose) -> Vec2 {
	seam:=seam_neighbours(s,sub,rest); defer delete(seam.incident); defer delete(seam.direct)
	return cosmetic_seam_point(s,sub,rest,poses,seam)
}
common_boundary_point :: proc(s: ^Scene,sub: Subdivision,rest: Vec2,poses: map[u64]Pose) -> Vec2 {
	seam:=seam_neighbours(s,sub,rest); defer delete(seam.incident); defer delete(seam.direct)
	return common_seam_point(s,sub,rest,poses,seam)
}
render_outline :: proc(s: ^Scene,sub: Subdivision,poses: map[u64]Pose,surface: bool,frames: map[u64]Pose = nil) -> Polygon {
	cache:=ensure_render_cache(s,sub.id)
 outline:=make_polygon(cache.outline.points)
 if s.materials[sub.material].flexibility==0 {
  frame:=rigid_render_frame(s,sub,poses,frames)
  for rest,i in cache.outline.points { outline.points[i]=rigid_render_point(frame,rest) }
  return outline
 }
 posed:=render_subdivision(s,sub,poses)
 for rest,i in cache.outline.points {
  if surface { outline.points[i]=common_seam_point(s,sub,rest,poses,cache.seams[i]) }
  else { outline.points[i]=posed_point(posed,rest) }
 }
 return outline
}
draw_cached_fill :: proc(view: View,outline: Polygon,color: rl.Color,cache: ^Render_Cache) {
	indices:=cache.triangles[:]
	for i:=0; i+2<len(indices); i+=3 {
		a,b,c:=screen_point(view,outline.points[indices[i]]),screen_point(view,outline.points[indices[i+1]]),screen_point(view,outline.points[indices[i+2]])
		// Near-collinear triangles can flip orientation after screen rounding.
		cross:=(f64(b.x)-f64(a.x))*(f64(c.y)-f64(a.y))-(f64(b.y)-f64(a.y))*(f64(c.x)-f64(a.x))
		if cross<0 { rl.DrawTriangle(a,b,c,color) }
		else { rl.DrawTriangle(c,b,a,color) }
	}
 // Only exposed/cracked boundaries get a fill-coloured seal, even in F3.
 draw_cached_strokes(view,outline,color,1,cache,false)
}
stroke_style :: proc(width: f32,color: rl.Color) -> (f32,rl.Color) {
 if width<=0 { return 0,color }
 if width<1 { tint:=color; tint.a=u8(f32(color.a)*width); return 1,tint }
 return width,color
}
draw_cached_strokes :: proc(view: View,outline: Polygon,color: rl.Color,width: f32,cache: ^Render_Cache,region_outlines: bool) {
 pixels,tint:=stroke_style(width,color)
 if pixels==0 { return }
 for point,i in outline.points {
  if region_outlines || cache.draw_edge[i] { rl.DrawLineEx(screen_point(view,point),screen_point(view,outline.points[(i+1)%len(outline.points)]),pixels,tint) }
 }
}
