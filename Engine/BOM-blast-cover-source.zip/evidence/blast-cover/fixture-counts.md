| Fixture | Before cells/links/pieces | After | Delta |
|---|---|---|---|
| before-blasts.json | (243, 235, 124) | (228, 333, 79) | (-15, 98, -45) |
| before-glass/impact.json | (209, 386, 57) | (209, 386, 57) | (0, 0, 0) |
| before-glass/nonglass-v3.json | (253, 235, 134) | (240, 333, 91) | (-13, 98, -43) |
| before-glass/pane-r3.json | (275, 491, 59) | (272, 491, 56) | (-3, 0, -3) |
| before-glass/pane-r4.json | (345, 381, 194) | (345, 381, 194) | (0, 0, 0) |
| before-ticked.json | (296, 232, 179) | (257, 344, 104) | (-39, 112, -75) |
| before-wood/nonwood-v3.json | (253, 235, 134) | (263, 284, 128) | (10, 49, -6) |
| before-wood/seed-01.json | (84, 144, 15) | (84, 144, 15) | (0, 0, 0) |
| before-wood/seed-02.json | (103, 162, 23) | (103, 162, 23) | (0, 0, 0) |
| before-wood/seed-03.json | (98, 159, 19) | (98, 159, 19) | (0, 0, 0) |
| before-wood/seed-04.json | (100, 142, 28) | (100, 142, 28) | (0, 0, 0) |
| before-wood/seed-05.json | (96, 156, 20) | (96, 156, 20) | (0, 0, 0) |
| before-wood/seed-06.json | (90, 146, 18) | (90, 146, 18) | (0, 0, 0) |
| before-wood/seed-07.json | (100, 162, 21) | (100, 162, 21) | (0, 0, 0) |
| before-wood/seed-08.json | (96, 159, 18) | (96, 159, 18) | (0, 0, 0) |
| before-wood/seed-09.json | (99, 161, 22) | (99, 161, 22) | (0, 0, 0) |
| before-wood/seed-10.json | (98, 167, 14) | (98, 167, 14) | (0, 0, 0) |
| before-wood/seed-11.json | (98, 151, 24) | (98, 151, 24) | (0, 0, 0) |
| before-wood/seed-12.json | (106, 177, 20) | (106, 177, 20) | (0, 0, 0) |
| before-wood/seed-13.json | (106, 169, 22) | (106, 169, 22) | (0, 0, 0) |
| before-wood/seed-14.json | (115, 186, 22) | (115, 186, 22) | (0, 0, 0) |
| before-wood/seed-15.json | (95, 151, 20) | (95, 151, 20) | (0, 0, 0) |
| before-wood/seed-16.json | (95, 145, 21) | (95, 145, 21) | (0, 0, 0) |
