package main

import "core:encoding/json"

Wire_Layout_Object :: struct { identity: u64, material: string, lo,hi: Vec2, mortar: union { bool } `json:"mortar,omitempty"` }
Wire_Layout :: struct {
	kind: string,
	version: int,
	seed: u64,
	next_identity: u64,
	objects: [dynamic]Wire_Layout_Object,
}
encode_layout :: proc(layout: ^Layout,seed: u8) -> ([]byte,bool) {
	wire:=Wire_Layout{kind="bom-layout",version=1,seed=u64(seed),next_identity=layout.next_identity}
	defer delete(wire.objects)
	for object in layout.objects {
		w:=Wire_Layout_Object{identity=object.identity,material=editor_material(object.material).name,lo=object.lo,hi=object.hi}
  if object.mortar { w.mortar=true }; append(&wire.objects,w)
	}
	return exact_json_encode(wire)
}
decode_layout :: proc(data: []byte) -> (layout: Layout,seed: u8,ok: bool,problem: string) {
	wire:=Wire_Layout{}
	defer {
		delete(wire.kind)
		for object in wire.objects { delete(object.material) }
		delete(wire.objects)
		if !ok { delete(layout.objects); layout={} }
	}
	if json.unmarshal(data,&wire)!=nil { return {},0,false,"Invalid layout JSON" }
	if wire.kind!="bom-layout" { return {},0,false,"Not a bom-layout file" }
	if wire.version!=1 { return {},0,false,"Unsupported layout version" }
	if wire.seed>255 { return {},0,false,"Seed must be between 0 and 255" }
	seen:=make(map[u64]bool); defer delete(seen)
	maximum:=u64(0)
	for object in wire.objects {
		choice:=Palette.Wood; known:=false
		for material in Palette { if object.material==editor_material(material).name { choice=material; known=true; break } }
		if !known { return layout,0,false,"Unknown material" }
		if object.identity==0 { return layout,0,false,"Object identity must be nonzero" }
		if seen[object.identity] { return layout,0,false,"Duplicate object identity" }
		r:=Authored_Rect{identity=object.identity,material=choice,lo=object.lo,hi=object.hi}
		if value,exists:=object.mortar.(bool); exists { r.mortar=value }
		if reason:=editor_rectangle_problem(&layout,r); reason!="" { return layout,0,false,reason }
		append(&layout.objects,r)
		seen[object.identity]=true; maximum=max(maximum,object.identity)
	}
	if wire.next_identity<=maximum { return layout,0,false,"next_identity must exceed every object identity" }
	layout.next_identity=wire.next_identity
	return layout,u8(wire.seed),true,""
}
sandbox_layout_changed :: proc(game: ^Sandbox) { game.layout_revision+=1 }
// A successful layout load is a build/replace path. Keep authored identities and
// the seed together, discard the damaged Test world, and return to paused Edit.
sandbox_replace_layout :: proc(game: ^Sandbox,layout: Layout,seed: u8) {
	delete(game.layout.objects); game.layout=layout
	game.world.settings.seed=seed
	game.editor.editing=true
	game.panel_open=false; game.layouts_open=false
	sandbox_reset(game)
	sandbox_layout_changed(game)
}
sandbox_load_layout_data :: proc(game: ^Sandbox,data: []byte) -> bool {
	layout,seed,ok,problem:=decode_layout(data)
	if !ok { sandbox_notice(game,problem); return false }
	sandbox_replace_layout(game,layout,seed)
	return true
}
