package main
import "core:slice"
import "core:time"
// Immutable pre-blast posed polygons, in stable cell-ID order. Intersection
// intervals support concave outlines and rays starting/ending inside material.
// Boundary-only contact has zero chord; descendants inherit their original owner.
Cover_Cell :: struct { id,owner:u64, resistance:f32, points:[]Vec2, lo,hi:Vec2 }
Cover :: struct { cells:[dynamic]Cover_Cell, owners:map[u64]u64 }
@(thread_local) active_cover:^Cover
cover_begin :: proc(s:^Scene) -> Cover {
 c:=Cover{owners=make(map[u64]u64)}
 ids:[dynamic]u64; defer delete(ids)
 for sub in s.subdivisions { if sub.live { append(&ids,sub.id) } }; sort_ids(ids[:])
 for id in ids {
  sub:=s.subdivisions[s.sub_rows[id]]; c.owners[id]=sub.owner
  resistance:=s.materials[sub.material].blast_resistance; if resistance==0 { continue }
  cell:=Cover_Cell{id=id,owner=sub.owner,resistance=resistance,points=make([]Vec2,len(sub.outline.points)),lo={1e30,1e30},hi={-1e30,-1e30}}
  for p,i in sub.outline.points { q:=posed_point(sub,p); cell.points[i]=q; cell.lo={min(cell.lo.x,q.x),min(cell.lo.y,q.y)}; cell.hi={max(cell.hi.x,q.x),max(cell.hi.y,q.y)} }
  append(&c.cells,cell)
 }; return c
}
cover_destroy :: proc(c:^Cover) { for cell in c.cells { delete(cell.points) }; delete(c.cells); delete(c.owners) }
cover_distance :: proc(point,origin:Vec2,owner:u64) -> f32 {
 when BOM_PROFILE { started:=time.tick_now(); defer profile_add(15,started) }
 delta:=vsub(point,origin); distance:=vlen(delta)
 if active_cover==nil || distance==0 { return distance }
 lo:=Vec2{min(point.x,origin.x),min(point.y,origin.y)}; hi:=Vec2{max(point.x,origin.x),max(point.y,origin.y)}
 cuts:[dynamic]f32; defer delete(cuts)
 for cell in active_cover.cells {
  if cell.owner==owner || hi.x<cell.lo.x || lo.x>cell.hi.x || hi.y<cell.lo.y || lo.y>cell.hi.y { continue }
  clear(&cuts); append(&cuts,0,1)
  for a,i in cell.points {
   b:=cell.points[(i+1)%len(cell.points)]; edge:=vsub(b,a); den:=vcross(delta,edge)
   if den==0 { continue }
   t:=vcross(vsub(a,origin),edge)/den; u:=vcross(vsub(a,origin),delta)/den
   if t>0 && t<1 && u>=0 && u<=1 { append(&cuts,t) }
  }
  slice.sort(cuts[:]); fraction:f32
  for i in 0..<len(cuts)-1 {
   mid:=vadd(origin,vmul(delta,(cuts[i]+cuts[i+1])*0.5)); inside:=false; boundary:=false
   for a,j in cell.points { b:=cell.points[(j+1)%len(cell.points)]; e:=vsub(b,a); m:=vsub(mid,a); if vcross(e,m)==0 && vdot(m,e)>=0 && vdot(m,e)<=vdot(e,e) { boundary=true }; if (a.y>mid.y)!=(b.y>mid.y) && mid.x<(b.x-a.x)*(mid.y-a.y)/(b.y-a.y)+a.x { inside=!inside } }
   if inside && !boundary { fraction+=cuts[i+1]-cuts[i] }
  }
  distance+=cell.resistance*vlen(delta)*fraction
 }
 return distance
}
cover_sample_distance :: proc(sub:Subdivision,point,origin:Vec2) -> f32 {
 owner:=sub.owner
 if active_cover!=nil { owner=active_cover.owners[sub.id] }
 return cover_distance(point,origin,owner)
}
cover_external :: proc(sub:Subdivision) -> bool {
 if active_cover==nil { return false }
 owner:=active_cover.owners[sub.id]
 for cell in active_cover.cells { if cell.owner!=owner { return true } }; return false
}
