package main
import "core:testing"
import "core:sync"
import "core:strings"
@(test)
cover_chords_endpoints_concavity_and_self :: proc(t:^testing.T) {
 points:=[6]Vec2{{0,0},{2,0},{2,1},{1,1},{1,2},{0,2}}
 cover:=Cover{}; append(&cover.cells,Cover_Cell{id=1,owner=7,resistance=3,points=points[:],lo={0,0},hi={2,2}}); defer delete(cover.cells)
 active_cover=&cover; defer { active_cover=nil }
 testing.expect(t,close(cover_distance({3,0.5},{-1,0.5},8),10))
 testing.expect(t,close(cover_distance({3,0.5},{-1,0.5},7),4))
 testing.expect(t,close(cover_distance({0.5,0.5},{-1,0.5},8),3))
 testing.expect(t,close(cover_distance({3,1.5},{-1,1.5},8),7))
 testing.expect(t,close(cover_distance({3,0},{-1,0},8),4))
 testing.expect(t,close(cover_distance({3,3},{-1,3},8),4))
}
@(test)
cover_material_roundtrip :: proc(t:^testing.T) {
 sync.mutex_lock(&physics_test_mutex); defer sync.mutex_unlock(&physics_test_mutex)
 g:=sandbox_editor_create(); defer sandbox_destroy(&g)
 g.world.scene.materials[0].blast_resistance=transmute(f32)u32(0x80000000)
 data,ok:=encode_world_snapshot(&g.world); defer delete(data); testing.expect(t,ok && strings.contains(string(data),"blast_resistance"))
 copy,decoded:=decode_world_snapshot(data); testing.expect(t,decoded); defer { scene_destroy(&copy.scene); delete(copy.bombs) }
 for m,i in g.world.scene.materials { testing.expect(t,transmute(u32)m.blast_resistance==transmute(u32)copy.scene.materials[i].blast_resistance) }
 again,encoded:=encode_world_snapshot(&copy); defer delete(again); testing.expect(t,encoded && string(data)==string(again))
 legacy,loaded:=decode_world_snapshot(transmute([]byte)#load("../evidence/world-v3/before-v2-ticked.json")); testing.expect(t,loaded); defer { scene_destroy(&legacy.scene); delete(legacy.bombs) }
 for m in legacy.scene.materials { testing.expect(t,m.blast_resistance==0) }
 wire:=read_world_state(&g.world); defer release_world_state(&wire); wire.scene.materials[0].blast_resistance=f32(-1)
 invalid,_:=exact_json_encode(wire); defer delete(invalid)
 rejected,accepted:=decode_world_snapshot(invalid); testing.expect(t,!accepted); if accepted { scene_destroy(&rejected.scene); delete(rejected.bombs) }
}

@(test)
cover_wall_protects_wood :: proc(t:^testing.T) {
 sync.mutex_lock(&physics_test_mutex); defer sync.mutex_unlock(&physics_test_mutex)
 g:=sandbox_editor_create(); defer sandbox_destroy(&g)
 g.editor.palette=.Stone; testing.expect(t,editor_place(&g,{2,0},{2.4,2.4})); g.editor.palette=.Wood; testing.expect(t,editor_place(&g,{2.6,0},{3.6,1.6})); sandbox_toggle_editor(&g)
 when #config(BOM_COVER_TEST_BASELINE,false) { for &m in g.world.scene.materials { m.blast_resistance=0 } }
 cover_wood_failures=0; blast_pass(&g.world.scene,Blast{{1,1},5})
 area:f32; for sub in g.world.scene.subdivisions { if sub.live && g.world.scene.materials[sub.material].name=="wood" { area+=polygon_area(sub.outline) } }
 testing.expect(t,1.6-area<0.001 && cover_wood_failures==0,"Wall must prevent Wood cell failure")
}
