# BOM — World state, snapshots and polish

Completed A–E in order. Odin `dev-2026-05-nightly:ea5175d`, bundled Box2D 3.1.1 build recipe, raylib 5.5; Windows, 60 Hz, four physics substeps. No strengths, recipes, blast/impact laws, weld parameters or player tuning changed. No networking added.

## Before / after

New checks were run before their fixes. Zero baselines below already passed and needed no fix.

| Check | Before | After |
|---|---:|---:|
| A: frame-side simulation mutations (blast, radius, pause timers) | 3 | 0 |
| A: changed v2 blast / 600-tick fixture files | 0 / 0 | 0 / 0 |
| B: mismatching or missing wire f32 values | 475 | 0 |
| B: restored bombs, from a saved pair | 0 / 2 | 2 / 2, exact |
| B: rain / tick restored | no / no | yes / yes |
| B: re-encoding produces identical bytes | no | yes |
| B: actual v2 fixture load / validation errors | 0 | 0 |
| B: unequal same-process 600-tick v3 replays | 0 | 0 |
| D: live, posed cross-piece Glass crack boundaries (minimum 10) | 58 | 58 |
| D: bright pixels within Glass silhouettes, width 0 | 8,943 | 0 |
| E: radius cases: floor r=5; Glass r=5; Glass r=1 | 5 / 5 / 1 | 3 / 3.8 / 0 |
| E: failing radius cases | 3 | 0 |

B's 240-tick falling-bombs fixture adds a controlled late drop on its last tick to guarantee one airborne and one landed bomb. The float comparison includes geometry, rest centres, cell poses, materials, player/bomb motion and timers, settings and rain delay, including tiny values and negative zero. Rain random words, tick and bomb count are also compared. Handles, contact-derived player support, interpolation and visual effects are excluded.

D uses the corrected **6×4 Glass at (0,0)–(6,4), blast (-0.1,2), radius 5**, the Wood fixture camera `{offset={140,700}, scale=150}`, 120 settle ticks, and no tick after the blast. Actual default-framebuffer MSAA: **4 samples, 1 sample buffer**, 1600×1000 physical pixels at 1.25 DPI. The strict metric checks **407,682 glass pixels**, without excluding crack or silhouette edges. Opaque colour alone left 541 floor-seal pixels at the bottom edge; drawing static fills before moving objects removed those. Existing MSAA interior, floor and Rubber-film defects remain **0**. D and E each preserve both v3 fixture files byte-for-byte against B.

## A: mutation sites outside `world_tick`

Normal play sends settings, debug edits and ordered manual blasts through `world_tick`. Only the first fixed step consumes queued commands; subsequent steps carry move. UI pause/input clearing now touches presentation only.

- **Build/reset/toggle:** `sandbox_editor_create`, `sandbox_reset`, `sandbox_toggle_editor`; construction helpers `editor_build_objects`, `editor_build_rectangles`, `sandbox_add_ground`, `sandbox_start_physics` / `world_start_physics`. These build or replace the World from Layout and settings.
- **Load:** the L branch in `sandbox_inspect_input` replaces the World. `decode_world_snapshot`, `decode_snapshot` / `decode_scene_state`, and `restore_body_state` construct restored records and derived bodies. V1/v2 loads start the player at spawn, without bombs, with seed-42 default settings/rain.
- **Teardown:** `sandbox_destroy` / `scene_destroy` release owned simulation allocations and engine objects.
- **Fixtures only:** `sandbox_explode`, `sandbox_fixture_blast`, `sandbox_fixture_radius`, `sandbox_fixture_mode`, `sandbox_remove_out_of_bounds`, `bomb_spawn`, `soak_yard`, `soak_rebuild_layout`, measurement setup, and direct scene/physics/player/body edits in unit/native smoke fixtures. The interactive frame loop does not call these mutation helpers.
- **Derived rendering data:** `ensure_render_cache` / `release_render_cache` rebuild `Scene`'s existing render caches during drawing. They change no simulation record or snapshot bytes; Scene's cache ownership remains unchanged.

## C: measurements only

Both specified scenarios use `soak_yard`, seed 42, radius 5 and idle player. Manual blasts use the allowed fixture explosion helper. A continues the original world; B decodes S into a fresh engine world. Tick numbers below are relative to S.

| Scenario | First bitwise motion difference | Max position difference at +600 | Regions / links / pieces A → B | next_id A → B |
|---|---:|---:|---|---|
| Manual: 120, blast, 120, blast, 60 | 1 | 0.077821374 units | 255 / 298 / 115 → same | 1765 → 1765 |
| Falling bombs: 600 ticks | 1 | 6.786999702 units | 255 / 41 / 226 → 259 / 32 / 235 | 4382 → 4572 |

Manual counts and next_id match; falling-bomb counts and next_id do not. Maximum position difference covers shared cell IDs, player, and corresponding live bomb slots. The falling result also has **206 unmatched entity records** across the two worlds. Decoding restores wire floats exactly, but rebuilding derived Box2D state does **not** provide bit-identical continuation. These measurements caused no simulation changes.

| V3 snapshot | Pretty bytes | Compact bytes |
|---|---:|---:|
| Re-baselined 600-tick fixture, 300 regions | 308,081 | 166,573 |
| Five-minute falling-bombs peak, 354 regions at tick 443 | 369,741 | 203,922 |

The five-minute run has **18,000 ticks, no replenishment, 172 explosions**. Worst single blast: **17.026800 ms**, tick **196**, with **256 live regions immediately before the blast**. Peak counts are sampled at completed ticks. Timings use the optimized build and include the complete `blast_pass`.

## Verification and deliverables

**103 tests pass** (99 originally); Odin test allocation tracking reports no leaks. The measurement harness explicitly ends at **0 Odin bytes / 0 Box2D bytes**. Native input smoke passes, including F3 v3 save/load. Both final v3 fixtures match B byte-for-byte, and each fixture run checks two sequential identical replays.

Reproduce: `odin test src -o:speed -out:build/BOM-tests.exe`; `scripts/bom.ps1 Build`; then `build/BOM.exe --soak-fixture`, `--measure-world`, `--smoke-input`, `--smoke-msaa`, or `--smoke-aim` from the project root. Detailed logs and baseline/current fixtures are in `evidence/world-v3/`.

- [Source archive](BOM-world-v3-source.zip)
- [Glass blast, width 0](evidence/world-v3/glass-blast-width-0.png)
- [Aim rings with Glass](evidence/world-v3/aim-glass.png)
