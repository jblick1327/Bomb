# Odin destruction sandbox

A playable destruction yard built with Odin's bundled Box2D, raylib and raygui libraries. Draw rectangles from four materials, test the layout, and explore its destruction with blasts or falling bombs.

## Run

Requires Odin on `PATH`, with compiled `vendor:box2d` and `vendor:raylib` libraries. Previously tested on Windows with Odin `dev-2026-05-nightly:ea5175d`.

```powershell
.\scripts\bom.ps1              # Run the sandbox
.\scripts\bom.ps1 Build        # Build an optimized executable
.\scripts\bom.ps1 Test         # Run the test suite
.\scripts\bom.ps1 Smoke        # Capture a hidden-window smoke test
.\scripts\bom.ps1 SmokeInput   # Exercise native input and widgets
.\scripts\bom.ps1 Soak         # Run the headless longevity check
```

The helper runs from the project root and creates `build/` and `output/`. Direct launches should also use the project root as their working directory.

## Play

The application starts paused in **Edit**. Choose Wood, Glass, Rubber or Stone, then drag rectangles into the empty area above the destructible floor. Click **Test** or press Enter to simulate the layout. Settings include falling bombs, blast radius and outlines. Closing the application discards the authored layout; v3 snapshots preserve the simulation World (including player, bombs, rain and tick), not the authored editor layout.

| Control | Action |
| --- | --- |
| Left drag in Edit | Preview and place a rectangle using the selected material |
| Right click in Edit | Remove the authored object under the cursor |
| Edit / Test button or Enter | Start a fresh test / restore the undamaged edit layout |
| A / D or left / right arrows in Test | Move |
| Space in Test | Jump, with a 0.1 second jump buffer and coyote window |
| Left click in Test | One blast at a valid cursor position |
| Mouse wheel over the world in Test | Adjust blast radius and power |
| R / Reset button in Test | Rebuild the same authored layout and seed |
| Tab / Escape / Settings button | Open settings and pause; close to resume |
| F3 in Test | Show every region outline, IDs, connections and inspection tools |

See [gameplay and defaults](docs/gameplay.md) for material presets, placement limits, inspection controls.


## Physics damage

Blasts and impacts can fracture the authored objects. See the [technical reference](docs/technical-reference.md#physics-damage) for the current damage rules and measured thresholds, and the [implementation guide](docs/implementation.md) for the source map and simulation details.

## Verification and cleanup

See [verification details](docs/verification.md) for coverage, output names and graphics requirements. [Historical evidence](evidence/README.md) contains preserved reports, captures and source snapshots.

```powershell
.\scripts\clean.ps1           # Preview generated build/ and output/ files
.\scripts\clean.ps1 -Apply    # Remove those directories
```

Move any snapshots or captures you want to retain into `evidence/` before cleaning. New evidence belongs with its report and related files; `build/` and `output/` are ignored by Git.

## Project layout

- [src/](src/) ? game code and tests in one Odin package.
- [scripts/](scripts/) ? run, build, test and cleanup helpers.
- [docs/](docs/) ? gameplay, implementation, verification, technical reference and historical plans.
- [benchmarks/recursive-blast-bench/](benchmarks/recursive-blast-bench/) ? standalone benchmark and recorded inputs.
- [evidence/](evidence/README.md) ? historical reports, captures and unique archives.
