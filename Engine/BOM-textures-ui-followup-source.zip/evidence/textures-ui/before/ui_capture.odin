package main
import rl "vendor:raylib"
import "core:os"
import "core:fmt"

run_ui_captures :: proc(directory:string) {
 assert(os.make_directory_all(directory)==nil)
 rl.SetTraceLogLevel(.WARNING); rl.SetConfigFlags({.MSAA_4X_HINT,.WINDOW_HIDDEN,.WINDOW_HIGHDPI})
 rl.InitWindow(1280,800,"BOM UI capture"); defer rl.CloseWindow()
 sandbox_gui_style(); rl.SetShapesTexture(rl.Texture2D{},rl.Rectangle{}); rl.SetTargetFPS(0)
 target:=rl.LoadRenderTexture(1280,800); defer rl.UnloadRenderTexture(target)
 g:=sandbox_editor_create(); defer sandbox_destroy(&g)
 assert(sandbox_load_preset(&g,0)); assert(materials_duplicate(&g,.Wood))
 g.layout_directory="output/ui-capture-layouts"; assert(os.make_directory_all(g.layout_directory)==nil)
 assert(sandbox_save_current_layout(&g)); sandbox_autosave_layout(&g)
 poses:=make(map[u64]Pose); defer delete(poses)
 for i in 0..<6 {
  if i==1 { sandbox_toggle_editor(&g) }
  if i==2 { sandbox_toggle_editor(&g); sandbox_set_materials_panel(&g); g.material_selected=0; materials_sync_name(&g) }
  if i==3 { g.material_selected=4; materials_sync_name(&g) }
  if i==4 { sandbox_set_layouts_panel(&g,true) }
  if i==5 { sandbox_set_panel(&g,true) }
    rl.BeginDrawing(); rl.BeginTextureMode(target); rl.ClearBackground({19,28,42,255})
  sandbox_draw_world(&g,sandbox_view(1280,800),poses); sandbox_draw_hud(&g,1280,800)
  rl.EndTextureMode(); rl.EndDrawing()
  names:=[6]string{"edit-hud","test-hud","materials-builtin","materials-custom","layouts","settings"}
  path:=fmt.aprintf("%s/%s.png",directory,names[i]); sandbox_smoke_export(target,cstring_clone(path)); delete(path)
 }
}
cstring_clone :: proc(s:string)->cstring { return rl.TextFormat("%s",s) }

