# BOM textures and menu readability

Implemented one generated 512×512 RGBA8 repeating material tile, mipmaps/trilinear filtering, GLSL 330 tinting, and build-time rest UVs (`rest / 4`). Each static/moving pass batches its fills before flat one-pixel seals; borders, mortar, rubber film and F3 piece colours remain flat. Custom materials select their base family’s channel and retain their own RGB. Texture noise uses an independent fixed integer hash; Stone speckle seeds are 71/81. Simulation recipes, strengths and physics are unchanged.

Embedded [Inter 4.1](https://github.com/rsms/inter/releases/tag/v4.1) Regular/SemiBold static TTFs, with the SIL OFL 1.1 licence under `src/assets/fonts/`. Four separate DPI-aware atlases implement Title 26, Heading 18, Body 17 and Small 15; all UI text uses the helpers, and raygui uses Body. Fonts → raygui → shapes-texture reset is enforced at startup. B1 text/encoding grep checks return **0**.

Menus now have action labels and keycap chips, mode pills, swatch/name palette slots, an accent-filled selection, + New, grouped material lists, selected-entry duplication (including customs), disabled built-in controls and in-use Delete, stepped sliders with help/min/max, and file ages. Loaded values are not snapped. Modal notices appear once inside the modal; only explicit Reset emits “Yard reset”.

**157 tests pass**, including **48/48 byte-identical simulation captures** and **7/7 exact layout round-trips** (six v1 files and one v2). [Simulation manifest](byte-identity-manifest.json) · [Layout manifest](layout-byte-manifest.json). The old encoder upgraded v1 automatically; unedited loaded layouts now retain their original bytes, while edited/new layouts use canonical v2. Both retained buffers have explicit ownership and pass leak checks.

| Native check | Result |
|---|---|
| Actual 4× MSAA, fonts loaded | Wood 28 cells, Glass 110, Rubber 8, floor 153; **781,664** interior samples; max difference **1/255**, **0 defects** |
| Fragment tracking | 20 interior rest points, translation (0.45,0.2), rotation 30°, 512 physical px/m; max **2/255**, **0 defects** |
| Grain at 128 physical px/m | Built 4×0.8 plank / 0.8×4 post: across/along luminance ratios **34.604 / 34.751**, both ≥3 |
| Wood study axis | **0 / 1,897** live cells differ from the horizontal plank axis across seeds 1–16 after the standard blast |
| 2×2 mean-colour blocks | All four built-ins and both custom Wood tints within **0.899/255** per channel |
| Tile wrap/interior neighbour ratio, X / Y | Wood **0.061 / 0.733**; Glass **1.003 / 0.980**; Rubber **0.323 / 0.452**; Stone **0.868 / 0.918**; all ≤1.25 |
| UI, native suites, teardown | Six screens: **0 text overflows**; SmokeInput, SmokeMaterials and SmokeEditor pass; Odin **0**, Box2D **0**, texture/shader IDs **0**, fonts unloaded |

Fixture details: continuity uses editor seed 42/identity 1 and the specified plank, pane, pad and floor. The fragment is native Wood cell 135 after blast (-0.1,0.4), radius 4; sampling is at physical pixels on this 1.25-DPI display. Mean checks use the same 2×2 window starting at rest (2.5,3), chosen once by closest quarter-tile mean across all channels. At origin (0,0), the Wood red mean was +2.36/255 because a quarter-tile can have a local bias; the texture recipe was not changed. Actual means (R,G,B): Wood **179.883,135.905,81.954**; Glass **85.863,152.746,173.688**; Rubber **161.711,111.819,183.630**; Stone **131.151,145.143,152.148**; coral **230.566,103.937,90.943**; yellow **235.102,214.853,118.932**. Red clips in **3,741** coral and **7,824** yellow samples. Yellow green has 12 samples rounded to 255, with no actual clipping; other channels do not clip.

| Full-frame benchmark | Median before → after | Change |
|---|---|---|
| Blast frame | 14.27785 → 13.74555 ms | -3.73% |
| Following frame | 9.15455 → 9.22565 ms | +0.78% |

Three sequential runs per build, eight actual explosions after tick 600 per run and each immediate successor: 24 samples of each kind. This replaces fixed historical tick targets that might not contain a blast. Both builds use speed optimisation, 1280×800 logical / 1600×1000 physical, 4× MSAA, no FPS sleep and GPU completion. Event ticks and cell/link/piece counts match. No optimisations beyond the requested batching were added. [Raw/summary timing split](bench-summary.json):

| ms, median | Tick (includes blast/physics) | Draw submission/swap | Cache (within draw) | GPU finish |
|---|---|---|---|---|
| Blast | 7.244 → 6.723 | 3.937 → 4.308 | 0.562 → 0.477 | 1.698 → 3.110 |
| Next | 2.285 → 2.157 | 4.582 → 4.579 | 0.098 → 0.095 | 1.443 → 1.382 |

Component medians need not sum to the full-frame median. The report uses the final sequential before/after sample, superseding preliminary timings.

PNGs: [2× close-up montage](after/texture-closeups.png), [Materials preset after blast](after/materials-after-blast.png), [same layout in Edit](after/materials-edit.png). The shot uses blast (-7.5,1), radius 4, then 30 ticks: the earlier Glass-edge radius-5 shot erased the pane, so the Wood-edge fixture better shows textured fragments while retaining the other materials.

| Screen pair | Before | After |
|---|---|---|
| edit-hud | [PNG](before/edit-hud.png) | [PNG](after/edit-hud.png) |
| test-hud | [PNG](before/test-hud.png) | [PNG](after/test-hud.png) |
| materials-builtin | [PNG](before/materials-builtin.png) | [PNG](after/materials-builtin.png) |
| materials-custom | [PNG](before/materials-custom.png) | [PNG](after/materials-custom.png) |
| layouts | [PNG](before/layouts.png) | [PNG](after/layouts.png) |
| settings | [PNG](before/settings.png) | [PNG](after/settings.png) |

Reproduce: `odin build src -o:speed -define:BOM_FRAME_BENCH=true -out:build/BOM.exe`; run `--check-textures`, `--smoke-input`, `--smoke-materials`, `--smoke-msaa`, `--capture-ui`, `--capture-textures`, `--bench-frames`. `scripts/bom.ps1 Test` runs the unit suite. The accepted source and before-state capture/benchmark harness are retained under `evidence/textures-ui/before/`. Before screenshots use the original bitmap-font UI; saved-file rows reflect their actual modification times. The package includes both baseline and regenerated capture bytes, all PNGs and logs, fonts and licence.
