# Textures/UI follow-up

Removed the retained layout byte buffers and encoder comparison. Layout owns only authored state; every save produces canonical v2. Six v1 inputs (five presets and the real autosave) match their pre-change decoded objects, identities, next_identity and seed, then save as v2. The custom v2 file round-trips byte-identically. The reference files were captured from the accepted decoder before this change; the regression compares the complete canonical authored state against them.

Raygui disabled borders/base/text now use the requested theme colours. Material slider fills use the accent when enabled and 45% accent over the disabled track when disabled. Materials, Layouts and Settings have Title headings in title case with a separate muted Small Paused label. Mode pills measure their text and add 12 px padding on each side.

158 tests pass with memory tracking; native Materials smoke passes with Odin 0 and Box2D delta 0. All six UI captures have zero text overflows. All 48 freshly generated simulation captures match accepted bytes: see [byte-identity manifest](evidence/textures-ui-followup/byte-identity-manifest.json). Layout results are in the [layout manifest](evidence/textures-ui-followup/layout-manifest.json).

Fixture: reused the accepted 1280x800 UI capture sequence, Wood selected in both material captures. Slider rectangles are x=436..1115, y=247..260, 345..358 and 443..456; the comparison includes every disabled track, border and fill pixel. Enabled fill is sampled inside the toughness bar away from its border. Rec.709 luminance in 0..255 units: before disabled maximum 232.362 vs enabled fill 99.285 (fails); after 109.449 vs 194.661 (passes). The dimmed fill RGB is (65,122,116). No simulation fixture adjustment was needed.

Six after PNGs are under evidence/textures-ui-followup/after/: materials-builtin, materials-custom, layouts, settings, edit-hud, test-hud. The PNG bundle contains these six files.

Reproduce: odin test src; optimized build then --wood-study, --glass-study and --soak-fixture for the standard captures. Use MATERIAL_CAPTURE_DIRECTORY for the other 25 fixture captures, UI_LAYOUT_CAPTURE_DIRECTORY for the layout outputs, --capture-ui for screenshots, and --smoke-materials for native control and teardown checks. Run scripts from the project root. Historical evidence and reports describe their original runs.
