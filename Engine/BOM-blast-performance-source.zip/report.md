# Blast performance

Profiling is opt-in with `-define:BOM_PROFILE=true`; hooks compile out otherwise. All six serial 20-minute seed-42 runs use `-o:speed` and the same profiling hooks. No tests or graphics runs overlap. Tick means include profiling/logging overhead; phase totals exclude the final profile print. Phase/subquery timers are inclusive: refinement also includes provisional regrouping, and subquery timers overlap their enclosing phases. No rules, seeds, allocation order, physics step or tuning changed.

The profile contradicts the proposed shock-search bottleneck: the slowest baseline blast has essentially zero shock work. Refinement/generation and physics synchronization dominate. Fixes: padded rest-AABB rejection before inheritance/collision adjacency polygon tests; reuse original shared segments per attachment; failure/discard membership sets; reuse shock seed distances; collect shock bonds from incident lists while retaining sorted processing.

Timing (ms), before  ->  after: median worst **22.0044  ->  20.8979**; maximum worst **23.1973  ->  21.2140**; soak tick mean **0.808244  ->  0.801524**. Per-run worst: [20.442, 23.1973, 22.0044]  ->  [20.4179, 21.214, 20.8979].

Part A / Part B, same ten slowest baseline events matched by run and soak tick. Each timing cell is before  ->  after, ms. R=refinement, D=direct recursion, T=shock begin/travel, S=shock staging, B=shock bond breaks, G=regroup, C=commit, P=physics sync, I=impulses.

| Run/tick | Total | R | D | T | S | B | G | C | P | I |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2/43553 | 23.122 -> 16.683 | 9.795 -> 6.057 | 5.273 -> 4.090 | 0.001 -> 0.002 | 0.000 -> 0.000 | 0.000 -> 0.000 | 1.988 -> 1.247 | 1.406 -> 0.837 | 5.522 -> 4.867 | 0.300 -> 0.267 |
| 3/43553 | 21.923 -> 16.748 | 8.456 -> 6.266 | 5.754 -> 4.204 | 0.002 -> 0.001 | 0.000 -> 0.000 | 0.000 -> 0.000 | 1.683 -> 1.365 | 1.040 -> 0.801 | 5.543 -> 4.594 | 0.426 -> 0.272 |
| 2/21777 | 21.505 -> 17.443 | 8.327 -> 6.064 | 5.109 -> 4.428 | 0.026 -> 0.022 | 0.000 -> 0.000 | 0.000 -> 0.000 | 1.645 -> 1.301 | 0.998 -> 0.802 | 5.916 -> 5.299 | 0.351 -> 0.255 |
| 2/64843 | 20.414 -> 21.145 | 6.221 -> 6.325 | 5.539 -> 5.914 | 0.158 -> 0.205 | 0.643 -> 0.775 | 0.175 -> 0.059 | 2.121 -> 2.069 | 0.967 -> 1.048 | 5.300 -> 5.600 | 0.286 -> 0.256 |
| 1/43553 | 20.363 -> 16.775 | 8.220 -> 6.515 | 5.210 -> 3.796 | 0.002 -> 0.001 | 0.000 -> 0.000 | 0.000 -> 0.000 | 1.597 -> 1.375 | 0.874 -> 0.840 | 5.037 -> 4.707 | 0.269 -> 0.244 |
| 3/64843 | 20.226 -> 20.835 | 6.841 -> 6.548 | 5.103 -> 5.608 | 0.204 -> 0.175 | 0.635 -> 0.757 | 0.173 -> 0.047 | 2.262 -> 1.995 | 0.897 -> 1.077 | 5.297 -> 5.480 | 0.291 -> 0.234 |
| 3/21777 | 19.316 -> 18.375 | 6.764 -> 5.918 | 4.505 -> 5.136 | 0.022 -> 0.025 | 0.000 -> 0.000 | 0.000 -> 0.000 | 1.873 -> 1.418 | 1.242 -> 0.855 | 5.516 -> 5.482 | 0.277 -> 0.298 |
| 2/36252 | 19.195 -> 16.414 | 8.141 -> 6.936 | 4.592 -> 3.580 | 0.083 -> 0.074 | 0.000 -> 0.000 | 0.000 -> 0.000 | 2.115 -> 1.798 | 1.001 -> 0.787 | 4.106 -> 4.101 | 0.231 -> 0.177 |
| 1/64843 | 19.117 -> 20.099 | 5.825 -> 6.064 | 5.361 -> 5.542 | 0.194 -> 0.192 | 0.600 -> 0.645 | 0.175 -> 0.046 | 1.722 -> 1.908 | 0.929 -> 0.989 | 5.024 -> 5.462 | 0.240 -> 0.251 |
| 1/21777 | 18.480 -> 18.402 | 6.645 -> 6.160 | 4.192 -> 4.722 | 0.023 -> 0.022 | 0.000 -> 0.000 | 0.000 -> 0.000 | 1.475 -> 1.438 | 0.853 -> 0.851 | 5.750 -> 5.613 | 0.345 -> 0.299 |

Work counts for those events. Geometry/state/object counts match; inheritance tests are before  ->  after. Direct failure count includes all directly submitted recursion IDs; children include spatial refinement. Shared queries count calls across the blast, including physics decomposition.

| Run/tick | Regions/links before  ->  after | Direct/shock failed | Children | Inheritance pairs | Shared queries | Bodies/shapes created | Contains scans |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2/43553 | 226, 326  ->  260, 207 | 81/0 | 148 | 474 -> 240 | 1242 -> 1237 | 75/217 | 233 -> 0 |
| 3/43553 | 226, 326  ->  260, 207 | 81/0 | 148 | 474 -> 240 | 1242 -> 1237 | 75/217 | 233 -> 0 |
| 2/21777 | 255, 395  ->  292, 281 | 75/0 | 142 | 503 -> 237 | 1355 -> 1348 | 74/243 | 210 -> 0 |
| 2/64843 | 233, 510  ->  253, 326 | 97/18 | 160 | 387 -> 197 | 1474 -> 1436 | 99/265 | 289 -> 0 |
| 1/43553 | 226, 326  ->  260, 207 | 81/0 | 148 | 474 -> 240 | 1242 -> 1237 | 75/217 | 233 -> 0 |
| 3/64843 | 233, 510  ->  253, 326 | 97/18 | 160 | 387 -> 197 | 1474 -> 1436 | 99/265 | 289 -> 0 |
| 3/21777 | 255, 395  ->  292, 281 | 75/0 | 142 | 503 -> 237 | 1355 -> 1348 | 74/243 | 210 -> 0 |
| 2/36252 | 243, 445  ->  285, 342 | 69/0 | 143 | 469 -> 236 | 1158 -> 1156 | 80/181 | 213 -> 0 |
| 1/64843 | 233, 510  ->  253, 326 | 97/18 | 160 | 387 -> 197 | 1474 -> 1436 | 99/265 | 289 -> 0 |
| 1/21777 | 255, 395  ->  292, 281 | 75/0 | 142 | 503 -> 237 | 1355 -> 1348 | 74/243 | 210 -> 0 |

Nested stage/query timing, ms before  ->  after (inclusive).

| Run/tick | Generation | Inheritance loop | Sibling attachment | Contains scans | Shared boundary | Inherits query |
| --- | --- | --- | --- | --- | --- | --- |
| 2/43553 | 7.050 -> 5.040 | 2.712 -> 1.420 | 0.527 -> 0.358 | 0.026 -> 0.000 | 0.589 -> 0.467 | 1.475 -> 0.323 |
| 3/43553 | 6.687 -> 5.051 | 2.380 -> 1.472 | 0.673 -> 0.368 | 0.025 -> 0.000 | 0.580 -> 0.464 | 1.345 -> 0.328 |
| 2/21777 | 5.792 -> 4.884 | 2.883 -> 1.349 | 0.516 -> 0.396 | 0.022 -> 0.000 | 0.602 -> 0.456 | 1.431 -> 0.301 |
| 2/64843 | 5.964 -> 6.685 | 1.760 -> 1.247 | 0.414 -> 0.523 | 0.026 -> 0.000 | 0.594 -> 0.556 | 0.927 -> 0.279 |
| 1/43553 | 6.224 -> 5.001 | 2.173 -> 1.530 | 0.475 -> 0.372 | 0.022 -> 0.000 | 0.535 -> 0.558 | 1.138 -> 0.392 |
| 3/64843 | 5.993 -> 6.664 | 1.657 -> 1.420 | 0.522 -> 0.484 | 0.024 -> 0.000 | 0.555 -> 0.525 | 0.813 -> 0.319 |
| 3/21777 | 4.807 -> 5.041 | 1.959 -> 1.456 | 0.420 -> 0.508 | 0.021 -> 0.000 | 0.451 -> 0.465 | 1.070 -> 0.313 |
| 2/36252 | 5.876 -> 5.194 | 2.264 -> 1.425 | 0.447 -> 0.374 | 0.021 -> 0.000 | 0.512 -> 0.459 | 1.121 -> 0.311 |
| 1/64843 | 5.648 -> 6.079 | 1.518 -> 1.363 | 0.409 -> 0.445 | 0.025 -> 0.000 | 0.454 -> 0.488 | 0.819 -> 0.298 |
| 1/21777 | 4.721 -> 5.026 | 1.922 -> 1.764 | 0.445 -> 0.491 | 0.017 -> 0.000 | 0.468 -> 0.522 | 1.039 -> 0.340 |

The <=15 ms median / <=20 ms maximum target is **not met**. The slowest optimized profiled event is tick 64843, 21.145 ms: refinement 6.325, direct 5.914, generation subtime 6.685, physics sync 5.600. Further work needs reuse of immutable hull/partition queries during generation and transaction-local collision decomposition, preserving exact geometry and primitive order; this change does not defer work or alter fragmentation to meet the target.

Byte checks pass for all 23 blast/replay/control/pane/impact/Wood-study snapshots, and all three final 20-minute snapshots. Every minute matches its baseline live/stored/map/peak counts. Both fixture replays remain identical in-process. All six soaks report zero Odin/Box2D bytes after teardown. Test/MSAA results are recorded in the accompanying logs. No PNGs are included.

129 tests pass with allocation tracking and no leak reports; all actual-MSAA metrics remain 0 (including glass crack, floor and rubber film). `odin check src` and archive source check pass.
