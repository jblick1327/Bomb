# BOM mortar: strength per seam

Implemented seam-wide force breaking; building, blast breaking, inheritance, drawing and snapshot format are unchanged. No commit made.

## Calibration and failing baseline

Before changing simulation code, F1 was run with seeds 1-8 on the per-joint build, breaking disabled, sampling ticks 60-120 inclusive. Both studies use the original F1 coordinates: Stone (0,0)-(0.4,2), Wood (0,2)-(2.4,2.4), both mortar.

| Seed | N(F1), before | N(F1), after |
| ---: | ---: | ---: |
| 1 | 4353.775391 | 160.766663 |
| 2 | 708.406006 | 160.750031 |
| 3 | 160.832123 | 160.832092 |
| 4 | 320.097351 | 160.772552 |
| 5 | 992.187744 | 160.766190 |
| 6 | 4094.659424 | 160.778793 |
| 7 | 160.824158 | 160.824158 |
| 8 | 526.494873 | 160.754761 |
| **max/min** | **27.071651** | **1.000510** |

Target <=1.25 passes. Each seed partitions the support seam differently; aggregation removes the short-joint torque penalty. The remaining 0.051% spread is the measured response of the seed-dependent geometry and weld solver.

Seed-42 F1/F2 calibration, same prescribed fixtures and sampling window:

| Quantity | Before (per joint) | After (per seam) |
| --- | ---: | ---: |
| N(F1) | 375.444733 | 160.771973 |
| N(F2) | 1268.447144 | 487.842041 |
| N(F2)/N(F1) | 3.378519 | 3.034372 |
| Geometric mean | 690.095520 | 280.055939 |
| **MORTAR_STRENGTH**, 2 significant digits | **690** | **280** |

N(F2)>2*N(F1) passes. The two beam-support members (0.167579323 + 0.232420683 m) now form one 0.4 m seam.

## Force checking

Live valid joints are grouped by unordered body pair, ordered by smallest connection ID, with members sorted by ID. Reactions are oriented onto the same body before summing force and torque about the length-weighted world seam centre. The ratio uses the specified force and torque denominators directly. Every member receives the same counter; a breaking seam appends all members to one Failures batch. A newly composed group retains the maximum surviving member counter, then synchronises every member. Static-static null joints remain excluded.

New unit checks cover grouping and total length, shared counters, third-tick and immediate force/torque snapping, reset below threshold, and byte-identical snapshot restoration at counter 2. The initial new torque-threshold test exposed rounding from dividing a precomputed `need` by strength; using the specified denominators directly fixed it. No tuning or fixture change was used for this correction.

## Re-run of Parts A/B/C

| Check | Result |
| --- | --- |
| A1: build and validate | 1 block-to-block + 6 block-to-floor pairs; separate pieces; no mortar in piece.connections; valid scene. |
| A2: blast isolation | Seam load 25, max cell load 24.504902 < 35; mortar removed without changing block cells/owners. |
| A3: re-attachment | 3 direct bond breaks yield 2 beam pieces; supported cell moves off original body. All live joint endpoints match current bodies; scene valid. Both rebuilt support welds survive 60 ticks; maximum drop 0.001881957 m (was 0.002561212 m). |
| A4: snapshot | Mortar and counter=2 encode/decode/re-encode identical; restored welds valid. Group counter=2 also round-trips. |
| A5: layouts/ranges | Mortar round-trip and old-layout false default pass. Nonempty cell ranges/live owners for every object and floor in all 5 presets. |
| A6: glass isolation | Adjoining pane B keeps 100/100 original cells. |
| A7/B4: no-mortar regression | All 23 fixture files byte-identical; optional mortar fields absent. Two same-process 600-tick replays identical. |
| B1: F1, 600 ticks | 0 breaks, unchanged from before. |
| B2: F2 | First break tick 3 (before 2); all 3 joints broken by 240. Lowest beam-cell centre below y=1 at tick 29 (before 32). |
| C1: Bridge, 600 idle ticks | 0 force breaks; regions 272->272, links 592->592, pieces 5->5, mortar 6->6; 0 changed-count ticks. |
| C2: Bridge blast, next 180 ticks | Blast retires 2 mortar IDs, 0 inherited replacements: 6->4. Then 4 joints break by force: 4->0. Lowest deck vertex crosses y=1 at tick 93; minimum y=-0.000129715. Same counts/timing as before. |

All five preset settle checks pass with unchanged counts; Bridge maximum whole-piece rotation is 0.001662 degrees. No Bridge coordinate changes. No new fixture adjustments: A3 reuses the established editor fixture, Stone (-0.4,0)-(0.8,1), Wood (0,1)-(4,1.4), seed 42, isolating the smaller mortared beam part by breaking its 3 crossing bonds. This exercises body replacement without deleting its support cells.

## Validation and artifact

**137 tests pass**, including all 135 previous tests unchanged, with allocation tracking and no leak reports. Actual 4x MSAA defects remain **0**: interiors, floor, glass cracks (337 real crack boundaries), rubber film. Native input, editor/layout controls and Mortar controls pass. Editor teardown: Odin bytes 0, Box2D delta 0; capture teardown: Box2D bytes 0. Captures leave World snapshot bytes unchanged.

The 23 byte comparisons cover blast-only, 600-tick v3, non-glass control, glass radius-3/radius-4/impact studies, 16 wood-study seeds and non-wood control. Raw logs and SHA-256 comparison manifest are in `evidence/mortar-seams/`.

[Bridge 90 ticks after the C2 blast, width 2, actual-MSAA](bridge-blast-90.png).

Reproduce: `odin run src -- --mortar-seeds`, `odin run src -- --calibrate-mortar`, `odin test src -define:ODIN_TEST_TRACK_MEMORY=true`. Bridge force-count measurements use `-define:BOM_MORTAR_MEASURE=true -- --measure-mortar`; captures use `--capture-mortar output/mortar`.
